package com.mobiowin.windchim.image;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.imageio.ImageIO;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.windchim.commons.ApplicationConstant;
import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;

@Service("imageService")
@Component
public class ImageUrlService {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private @Resource Map<String, List<String>> imageconfig;

	public Map<String, String> getImageUrl(String orgId) {

		log.info("Inside ImageUrlservice/getImageUrl()");

		List<String> businessImageBasePath = (List<String>) imageconfig.get("ORG_DP_BASE_PATH");

		HashMap<String, String> imageUrlMap = null;

		String basePath = businessImageBasePath.get(0).trim();
		String urlAddress = businessImageBasePath.get(1).trim();
		String entityValue = businessImageBasePath.get(3).trim();

		if (log.isInfoEnabled()) {
			log.info("Base Path is    : " + basePath);
			log.info("Url Address is  : " + urlAddress);
			log.info("Entity value is : " + entityValue);
		}

		StringBuilder businessImagePath = new StringBuilder();
		businessImagePath.append(urlAddress);
		businessImagePath.append(ApplicationConstant.ENTITY);
		businessImagePath.append(ApplicationConstant.FLASH_VALUE_ASSIGNER);
		businessImagePath.append(entityValue);
		businessImagePath.append(ApplicationConstant.FLASH_URL_APPENDER);
		businessImagePath.append(ApplicationConstant.FLASH_IMAGE_ASSIGNER);
		businessImagePath.append(ApplicationConstant.FLASH_VALUE_ASSIGNER);
		businessImagePath.append(orgId);

		imageUrlMap = new HashMap<String, String>();
		imageUrlMap.put("displayImgUrl", businessImagePath.toString());

		return imageUrlMap;
	}

	public String saveDisplayImage(HashMap<String, String> profileDataMap) {
		log.info("Inside ImageUrlService/saveDisplayImage()");

		List<String> imaBasePathList = null;
		String destDirName = null;

		String dpImgPath = null;
		String profileImgUrl = null;

		if (profileDataMap.get(ApplicationConstant.USER_TYPE).equals(ApplicationConstant.ORG_ENTITY)) {
			imaBasePathList = (List<String>) imageconfig.get("ORG_DP_BASE_PATH");
			destDirName = imaBasePathList.get(0).trim();

			log.info("imaBasePathList : " + imaBasePathList);
			log.info("destDirName : " + destDirName);
		}

		else if (profileDataMap.get(ApplicationConstant.USER_TYPE).equals(ApplicationConstant.IND_ENTITY)) {
			imaBasePathList = (List<String>) imageconfig.get("IND_DP_BASE_PATH");
			destDirName = imaBasePathList.get(0).trim();

			log.info("imaBasePathList : " + imaBasePathList);
			log.info("destDirName : " + destDirName);
		}
		
		
		
		try
		{
			byte[] bytearray = Base64.decode(profileDataMap.get(ApplicationConstant.DISPLAY_IMAGE));
			BufferedImage imag = ImageIO.read(new ByteArrayInputStream(bytearray));
			String orgDisplayImgName = getImageName(profileDataMap.get(ApplicationConstant.ORG_ID));

			log.info("displayImgName : " + orgDisplayImgName);

			ImageIO.write(imag, "jpg", new File(destDirName, orgDisplayImgName));
			dpImgPath = destDirName + orgDisplayImgName;

			log.info("DpImgPath is : " + dpImgPath);

			Map<String, String> imageUrlMap = getImageUrl(orgDisplayImgName);
			profileImgUrl = imageUrlMap.get("displayImgUrl");

			log.info("display image url : " + profileImgUrl);

			return profileImgUrl;
		} catch (IOException e) {
			log.error("Exception in saving display image : " + e.getMessage());
			e.printStackTrace();
		}

		return profileImgUrl;
	}

	private String getImageName(String orgId)
	{
		log.info("Inside ProfileSyncService/getImageName()");

		String nanoTime = String.valueOf(System.nanoTime());
		nanoTime = nanoTime.substring(nanoTime.length() - 4, nanoTime.length());
		StringBuilder dpImgNameBuilder = new StringBuilder();
		dpImgNameBuilder.append(orgId);
		dpImgNameBuilder.append("_");
		dpImgNameBuilder.append(nanoTime);
		dpImgNameBuilder.append(".jpg");
		return dpImgNameBuilder.toString();
	}

	public ArrayList<String> saveAcievementImage(HashMap<String, Object> reqDataMap) 
	{
		
		log.info("Inside ImageUrlService/saveAcievementImage()");

		List<String> imaBasePathList = (List<String>) imageconfig.get("IMG_PATH_DIR");
		String destDirName = imaBasePathList.get(0).trim();
		String imgPath = null;
		ArrayList<String> imgUrlList = null;
		ArrayList<String> imgList = null;
		Map<String, String> imageUrlMap = null;
		String imgName = null;

		if (null != reqDataMap) 
		{
			imgList = (ArrayList<String>) reqDataMap.get(ApplicationConstant.ORG_ACHIEVEMENT_IMG);
		}

		try 
		{

			imgUrlList = new ArrayList<String>();
			for (String storeImg : imgList)
			{

				if (null != storeImg )
				{
					byte[] bytearray = Base64.decode(storeImg);
					BufferedImage imag = ImageIO.read(new ByteArrayInputStream(bytearray));
					imgName = getImageName(String.valueOf(reqDataMap.get(ApplicationConstant.ORG_ID)));
					ImageIO.write(imag, "jpg", new File(destDirName, imgName));
					imgPath = destDirName + imgName;
					log.info("image path is : " + imgPath);
					imageUrlMap = getAchievementImgUrl(imgName);
					String storeImgUrl = imageUrlMap.get("imgUrl");
					imgUrlList.add(storeImgUrl);
					log.info("image url : " + storeImgUrl);
				}
				else
				{
					imgUrlList.add("-");
				}
			}
			return imgUrlList;

		} catch (IOException e) {
			log.error("Exception in saving achievement image : " + e.getMessage());
			e.printStackTrace();
		}

		return imgUrlList;
	}

	private Map<String, String> getAchievementImgUrl(String imgName)
	{
		List<String> imageBasePath = (List<String>) imageconfig
				.get("ORG_ACHIEVEMENT_IMG_BASE_PATH");
		

		String basePath = imageBasePath.get(0).trim();
		String urlAddress = imageBasePath.get(1).trim();
		String entityType = imageBasePath.get(3).trim();

		if (log.isInfoEnabled())
		{
			log.info("Base Path is    : " + basePath);
			log.info("Url Address is  : " + urlAddress);
			log.info("Entity value is : " + entityType);
		}
		
		StringBuilder imagePath = new StringBuilder();
		imagePath.append(urlAddress);
		imagePath.append(ApplicationConstant.ENTITY);
		imagePath.append(ApplicationConstant.FLASH_VALUE_ASSIGNER);
		imagePath.append(entityType);
		imagePath.append(ApplicationConstant.FLASH_URL_APPENDER);
		imagePath.append(ApplicationConstant.FLASH_IMAGE_ASSIGNER);
		imagePath.append(ApplicationConstant.FLASH_VALUE_ASSIGNER);
		imagePath.append(imgName);

		HashMap<String, String> imageUrlMap = new HashMap<String, String>();
		imageUrlMap.put("imgUrl", imagePath.toString());
		return imageUrlMap;
	}

	public String saveDonateImage(HashMap<String, String> reqDataMap) 
	{
		List<String> imaBasePathList = null;
		String destDirName = null;

		String dpImgPath = null;
		String profileImgUrl = null;
		
		imaBasePathList = (List<String>) imageconfig.get("IND_DONATE_BASE_PATH");
		destDirName = imaBasePathList.get(0).trim();

		log.info("imaBasePathList : " + imaBasePathList);
		log.info("destDirName : " + destDirName);
		
		try
		{
			byte[] bytearray = Base64.decode(reqDataMap.get(ApplicationConstant.IMAGE_SERVLET_IMAGE_PARAM));
			BufferedImage imag = ImageIO.read(new ByteArrayInputStream(bytearray));
			String indDonateItemImgName = getImageName(reqDataMap.get(ApplicationConstant.NAME));

			log.info("indDonateItemImgName : " + indDonateItemImgName);

			ImageIO.write(imag, "jpg", new File(destDirName, indDonateItemImgName));
			dpImgPath = destDirName + indDonateItemImgName;

			log.info("DpImgPath is : " + dpImgPath);

			Map<String, String> imageUrlMap = getDonateImageUrl(indDonateItemImgName);
			profileImgUrl = imageUrlMap.get("donateItemImgUrl");

			log.info("display image url : " + profileImgUrl);

			return profileImgUrl;
		} catch (IOException e) {
			log.error("Exception in saving display image : " + e.getMessage());
			e.printStackTrace();
		}

		return profileImgUrl;
		
	}

	private Map<String, String> getDonateImageUrl(String indDonateItemImgName) {
		log.info("Inside ImageUrlservice/getDonateImageUrl()");

		List<String> businessImageBasePath = (List<String>) imageconfig.get("IND_DONATE_BASE_PATH");

		HashMap<String, String> imageUrlMap = null;

		String basePath = businessImageBasePath.get(0).trim();
		String urlAddress = businessImageBasePath.get(1).trim();
		String entityValue = businessImageBasePath.get(3).trim();

		if (log.isInfoEnabled()) {
			log.info("Base Path is    : " + basePath);
			log.info("Url Address is  : " + urlAddress);
			log.info("Entity value is : " + entityValue);
		}

		StringBuilder businessImagePath = new StringBuilder();
		businessImagePath.append(urlAddress);
		businessImagePath.append(ApplicationConstant.ENTITY);
		businessImagePath.append(ApplicationConstant.FLASH_VALUE_ASSIGNER);
		businessImagePath.append(entityValue);
		businessImagePath.append(ApplicationConstant.FLASH_URL_APPENDER);
		businessImagePath.append(ApplicationConstant.FLASH_IMAGE_ASSIGNER);
		businessImagePath.append(ApplicationConstant.FLASH_VALUE_ASSIGNER);
		businessImagePath.append(indDonateItemImgName);

		imageUrlMap = new HashMap<String, String>();
		imageUrlMap.put("donateItemImgUrl", businessImagePath.toString());

		return imageUrlMap;
	}

}
