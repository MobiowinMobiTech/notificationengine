package com.mobiowin.windchim.student;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.windchim.commons.ApplicationConstant;
import com.mobiowin.windchim.messaging.IMessageService;
import com.mobiowin.windchim.service.student.IStudentHelperService;

@Service("studentNotificationService")
@Component
public class StudentNotificationSyncService implements IMessageService {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private IStudentHelperService studentCoreHelperService;

	public Message<String> execute(Message<String> message) {

		log.info("Inside StudentNotificationSyncService/execute()");

		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject deviceDataJson = null;
		JSONObject deviceDatadetailJson = null;
		String userId = null;
		String branchId = null;
		String className = null;
		String imeiNo = null;
		String deviceId = null;
		String notificationId = null;

		String response = null;
		HashMap<String, String> studentNotificationDetailMap = null;

		try {
			deviceDataJson = new JSONObject(jsonData);
			deviceDatadetailJson = deviceDataJson.getJSONObject(ApplicationConstant.DATA);

			if (deviceDatadetailJson.has(ApplicationConstant.FLASH_USER_ID)) {
				userId = deviceDatadetailJson.getString(ApplicationConstant.FLASH_USER_ID);
			}

			if (deviceDatadetailJson.has(ApplicationConstant.BRANCH_ID)) {
				branchId = deviceDatadetailJson.getString(ApplicationConstant.BRANCH_ID);
			}

			if (deviceDatadetailJson.has(ApplicationConstant.CLASS_NAME)) {
				className = deviceDatadetailJson.getString(ApplicationConstant.CLASS_NAME);
			}

			if (deviceDatadetailJson.has(ApplicationConstant.IMEI_NO)) {
				imeiNo = String.valueOf(deviceDatadetailJson.getString(ApplicationConstant.IMEI_NO));
			}

			if (deviceDatadetailJson.has(ApplicationConstant.DEVICE_ID)) {
				deviceId = String.valueOf(deviceDatadetailJson.getString(ApplicationConstant.DEVICE_ID));
			}

			if (deviceDatadetailJson.has(ApplicationConstant.NOTIFICATION_ID)) {
				notificationId = String.valueOf(deviceDatadetailJson.getString(ApplicationConstant.NOTIFICATION_ID));
			}

			if (log.isInfoEnabled()) {
				log.info("messageHeaders is : " + messageHeaders);
				log.info("FLASH_USER_ID is : " + userId);
				log.info("BRANCH_ID is : " + branchId);
				log.info("Device id is : " + deviceId);
				log.info("CLASS_NAME is : " + imeiNo);
				log.info("Os version is : " + className);
				log.info("Notification id is : " + notificationId);
			}

			studentNotificationDetailMap = getDeviceDetailDataMap(userId, branchId, className, deviceId, imeiNo,
					notificationId);

			response = studentCoreHelperService.submitDeviceDetails(studentNotificationDetailMap);

			return MessageBuilder.withPayload(response).build();

		} catch (Exception e) {
			log.error("Exception in NotiicationSyncService/execute() : " + e.getMessage());
			return null;
		}

	}

	private HashMap<String, String> getDeviceDetailDataMap(String userId, String branchId, String className,
			String deviceId, String imeiNo, String notificationId) {

		HashMap<String, String> deviceDetailMap = new HashMap<String, String>();

		deviceDetailMap.put(ApplicationConstant.FLASH_USER_ID, userId);
		deviceDetailMap.put(ApplicationConstant.IMEI_NO, imeiNo);
		deviceDetailMap.put(ApplicationConstant.NOTIFICATION_ID, notificationId);
		deviceDetailMap.put(ApplicationConstant.DEVICE_ID, deviceId);
		deviceDetailMap.put(ApplicationConstant.BRANCH_ID, branchId);
		deviceDetailMap.put(ApplicationConstant.CLASS_NAME, className);

		return deviceDetailMap;
	}

}
