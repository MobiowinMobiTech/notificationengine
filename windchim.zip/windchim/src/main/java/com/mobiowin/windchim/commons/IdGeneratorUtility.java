package com.mobiowin.windchim.commons;

import java.util.HashMap;

public class IdGeneratorUtility {

	public static String generateOrgId(HashMap<String, String> orgDataMap) {

		StringBuilder orgIdBuilder = new StringBuilder();
		orgIdBuilder.append(ApplicationConstant.NAME);
		orgIdBuilder.append(getSystemNanoTime());
		return orgIdBuilder.toString();
	}

	public static String generateEventId(HashMap<String, String> orgDataMap) {
		StringBuilder eventIdbuilder = new StringBuilder();
		eventIdbuilder.append(String.valueOf(orgDataMap.get(ApplicationConstant.ORG_ID)));
		eventIdbuilder.append("_");
		eventIdbuilder.append(getSystemNanoTime());
		return eventIdbuilder.toString();
	}

	public static String generateRequestId(HashMap<String, String> orgDataMap) {
		StringBuilder eventIdbuilder = new StringBuilder();
		eventIdbuilder.append(String.valueOf(orgDataMap.get(ApplicationConstant.ORG_ID)));
		eventIdbuilder.append("_");
		eventIdbuilder.append(getSystemNanoTime());
		return eventIdbuilder.toString();
	}

	public static String generateAchievementId(HashMap<String, Object> orgDataMap) {
		StringBuilder eventIdbuilder = new StringBuilder();
		eventIdbuilder.append(String.valueOf(orgDataMap.get(ApplicationConstant.ORG_ID)));
		eventIdbuilder.append("_");
		eventIdbuilder.append("achievement");
		eventIdbuilder.append("_");
		eventIdbuilder.append(getSystemNanoTime());
		return eventIdbuilder.toString();
	}

	public static String generateMerchantStoreId(HashMap<String, Object> requestDataMap) {
		StringBuilder storeIdbuilder = new StringBuilder();
		storeIdbuilder.append(String.valueOf(requestDataMap.get(ApplicationConstant.MERCHANT_ID)));
		storeIdbuilder.append("_");
		storeIdbuilder.append(getSystemNanoTime());
		return storeIdbuilder.toString();
	}

	private static String getSystemNanoTime() {
		String nanoTime = String.valueOf(System.nanoTime());
		nanoTime = nanoTime.substring(nanoTime.length() - 4, nanoTime.length());
		return nanoTime;
	}

	public static String generateOtp() {
		
		return getSystemNanoTime();
	}

}
