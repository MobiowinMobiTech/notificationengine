package com.mobiowin.windchim.dao;

import java.util.HashMap;
import java.util.List;

import com.mobiowin.windchim.bean.BranchMasterBean;
import com.mobiowin.windchim.bean.BroadcastMasterBean;
import com.mobiowin.windchim.bean.ConnectBean;
import com.mobiowin.windchim.bean.DeviceDetailBean;
import com.mobiowin.windchim.bean.EventMasterBean;
import com.mobiowin.windchim.bean.ScreenMasterBean;
import com.mobiowin.windchim.bean.SliderMasterBean;
import com.mobiowin.windchim.bean.SurveyMasterBean;

public interface IAppSyncHelperDao {

	boolean validateAppVersion(HashMap<String, String> appReqDataMap);

	List<SliderMasterBean> syncAppBanner(String string);

	List<ScreenMasterBean> syncScreen(String string);

	List<BroadcastMasterBean> syncBroadcastTopic(String string);

	boolean isUserExist(DeviceDetailBean deviceDetailBean);

	String submitUser(DeviceDetailBean deviceDetailBean);

	String updateUser(DeviceDetailBean deviceDetailBean);

	String submitMessage(ConnectBean connectBean);

	List<BranchMasterBean> syncBranchDetails(String string);

	List<EventMasterBean> syncEvent(EventMasterBean eventMasterBean, String string);

	List<EventMasterBean> syncEventById(EventMasterBean eventMasterBean);

	String submitSurveyMessage(SurveyMasterBean surveyMasterBean);

}
