package com.mobiowin.windchim.geo;

public interface IGeoService {

}
