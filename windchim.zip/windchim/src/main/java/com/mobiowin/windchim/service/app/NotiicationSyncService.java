package com.mobiowin.windchim.service.app;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.windchim.commons.ApplicationConstant;
import com.mobiowin.windchim.messaging.IMessageService;
import com.mobiowin.windchim.service.helper.IAppSyncHelperServie;

@Service("notiicationIdSyncService")
@Component
public class NotiicationSyncService implements IMessageService {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private IAppSyncHelperServie appSyncService;
	
	public Message<String> execute(Message<String> message) 
	{
		log.info("Inside NotiicationSyncService/execute()");

		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject deviceDataJson = null;
		JSONObject deviceDatadetailJson = null;

		String deviceModel = null;
		String imeiNo = null;
		String deviceId = null;
		String osVersion = null;
		String notificationId = null;
		String response = null;
		HashMap<String,String> deviceDetailMap = null;

		try 
		{
			deviceDataJson = new JSONObject(jsonData);
			deviceDatadetailJson = deviceDataJson.getJSONObject(ApplicationConstant.DATA);

			if (deviceDatadetailJson.has(ApplicationConstant.IMEI_NO)) {
				imeiNo = String.valueOf(deviceDatadetailJson.getString(ApplicationConstant.IMEI_NO));
			}
			
			if (deviceDatadetailJson.has(ApplicationConstant.DEVICE_MODEL)) {
				deviceModel = String.valueOf(deviceDatadetailJson.getString(ApplicationConstant.DEVICE_MODEL));
			}

			if (deviceDatadetailJson.has(ApplicationConstant.DEVICE_ID)) {
				deviceId = String.valueOf(deviceDatadetailJson.getString(ApplicationConstant.DEVICE_ID));
			}

			if (deviceDatadetailJson.has(ApplicationConstant.OS_VERSION)) {
				osVersion = String.valueOf(deviceDatadetailJson.getString(ApplicationConstant.OS_VERSION));
			}

			if (deviceDatadetailJson.has(ApplicationConstant.NOTIFICATION_ID)) {
				notificationId = String.valueOf(deviceDatadetailJson.getString(ApplicationConstant.NOTIFICATION_ID));
			}
			
			if(log.isInfoEnabled())
			{
				log.info("messageHeaders is : " + messageHeaders);
				log.info("Device model is : " + deviceModel);
				log.info("Device id is : " + deviceId);
				log.info("IMEI_NO is : " + imeiNo);
				log.info("Os version is : " + osVersion); 
				log.info("Notification id is : " + notificationId);
			}
			
			deviceDetailMap = getDeviceDetailDataMap(deviceModel,deviceId,imeiNo,osVersion,notificationId);
			
			response = appSyncService.submitDeviceDetails(deviceDetailMap);

			return MessageBuilder.withPayload(response).build();

		} catch (Exception e) 
		{
			log.error("Exception in NotiicationSyncService/execute() : " + e.getMessage());
		}
		return null;
	}

	private HashMap<String, String> getDeviceDetailDataMap(String deviceModel, String deviceId, String imeiNo,
			String osVersion, String notificationId) 
	{
		HashMap<String,String> deviceDetailMap = new HashMap<String, String>();
		deviceDetailMap.put(ApplicationConstant.IMEI_NO, imeiNo);
		deviceDetailMap.put(ApplicationConstant.DEVICE_MODEL, deviceModel);
		deviceDetailMap.put(ApplicationConstant.DEVICE_ID, deviceId);
		deviceDetailMap.put(ApplicationConstant.OS_VERSION, osVersion);
		deviceDetailMap.put(ApplicationConstant.NOTIFICATION_ID, notificationId);
		
		
		return deviceDetailMap;
	}

}
