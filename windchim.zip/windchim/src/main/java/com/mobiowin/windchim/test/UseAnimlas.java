package com.mobiowin.windchim.test;

import java.sql.Timestamp;
import java.util.Date;

public class UseAnimlas {
	public static void main(String[] args) {
		/*Dog d = new Dog();
		
		d.callme();
		Dog d1 = (Dog)new Animal();
		d1.callme();*/
		
		String st = "akkk %1$s la,ala %2$s "; 
		String result = String.format(st, "First Val", "Second Val");
		
		System.out.println("result is : "  + result);
		
		//java.util.Date date = new Date();
		//Timestamp timestamp = new Timestamp(date.getTime());
		
		System.out.println("" + new Timestamp(new Date().getTime()));
		
	}
}

class Animal {
	public void callme() {
		System.out.println("In callme of Animal");
	}
}

class Dog extends Animal {
	public void callme() {
		System.out.println("In callme of Dog");
	}

	public void callme2() {
		System.out.println("In callme2 of Dog");
	}
}
