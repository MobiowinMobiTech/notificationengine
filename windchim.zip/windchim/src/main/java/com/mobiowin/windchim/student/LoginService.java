package com.mobiowin.windchim.student;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.windchim.commons.ApplicationConstant;
import com.mobiowin.windchim.messaging.IMessageService;
import com.mobiowin.windchim.service.student.IStudentHelperService;

@Service("loginService")
@Component
public class LoginService implements IMessageService {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private IStudentHelperService studentCoreHelperService;

	public Message<String> execute(Message<String> message) {
		log.info("Inside LoginService/execute()");

		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject reqDataJson = null;
		JSONObject loginDataJson = null;

		String userId = null;
		String password = null;
		String branchId = null;
		String imeiNo = null;

		String deviceId = null;
		String notificationId = null;
		String response = null;

		try {
			reqDataJson = new JSONObject(jsonData);
			loginDataJson = reqDataJson.getJSONObject(ApplicationConstant.DATA);

			if (loginDataJson.has(ApplicationConstant.FLASH_USER_ID)) {
				userId = loginDataJson.getString(ApplicationConstant.FLASH_USER_ID);
			}

			if (loginDataJson.has(ApplicationConstant.FLASH_PASSWORD)) {
				password = loginDataJson.getString(ApplicationConstant.FLASH_PASSWORD);
			}

			if (loginDataJson.has(ApplicationConstant.BRANCH_ID)) {
				branchId = loginDataJson.getString(ApplicationConstant.BRANCH_ID);
			}

			if (loginDataJson.has(ApplicationConstant.IMEI_NO)) {
				imeiNo = loginDataJson.getString(ApplicationConstant.IMEI_NO);
			}

			if (loginDataJson.has(ApplicationConstant.DEVICE_ID)) {
				deviceId = String.valueOf(loginDataJson.getString(ApplicationConstant.DEVICE_ID));
			}

			if (loginDataJson.has(ApplicationConstant.NOTIFICATION_ID)) {
				notificationId = String.valueOf(loginDataJson.getString(ApplicationConstant.NOTIFICATION_ID));
			}

			if (log.isInfoEnabled()) {
				log.info("Merchant Data is : " + loginDataJson);
				log.info("Message Headers : " + messageHeaders);
				log.info("Student enrollment id is : " + userId);
				log.info("School branch id is : " + branchId);
				log.info("Student password no is : " + password);
				log.info("Student imei no is : " + imeiNo);

				log.info("Notification id is : " + notificationId);
			}

			HashMap<String, String> loginReqDataMap = loginReqDataMap(userId, imeiNo, password, deviceId,
					notificationId, branchId);

			log.info("loginReqDataMap :" + loginReqDataMap);

			response = studentCoreHelperService.validateLogin(loginReqDataMap);

			return MessageBuilder.withPayload(response).build();

		} catch (Exception ex) {
			log.error("Exception in OrgLoginService/execute() " + ex.getMessage(), ex.getCause());
			return null;

		}

	}

	private HashMap<String, String> loginReqDataMap(String userId, String imeiNo, String password, String deviceId,
			String notificationId, String branchId) {
		HashMap<String, String> loginReqDataMap = new HashMap<String, String>();
		loginReqDataMap.put(ApplicationConstant.FLASH_USER_ID, userId);
		loginReqDataMap.put(ApplicationConstant.IMEI_NO, imeiNo);
		loginReqDataMap.put(ApplicationConstant.FLASH_PASSWORD, password);
		loginReqDataMap.put(ApplicationConstant.NOTIFICATION_ID, notificationId);
		loginReqDataMap.put(ApplicationConstant.DEVICE_ID, deviceId);
		loginReqDataMap.put(ApplicationConstant.BRANCH_ID, branchId);

		return loginReqDataMap;
	}

}
