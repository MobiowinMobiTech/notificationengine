package com.mobiowin.windchim.messaging;

import org.springframework.messaging.Message;

public interface IMessageReceiver {
	public Message<String> recieve(Message<String> message);
}
