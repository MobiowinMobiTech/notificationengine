package com.mobiowin.windchim.service.app;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.windchim.commons.ApplicationConstant;
import com.mobiowin.windchim.messaging.IMessageService;
import com.mobiowin.windchim.service.helper.IAppSyncHelperServie;

@Service("connectService")
@Component
public class ConnectService implements IMessageService{

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private IAppSyncHelperServie appSyncService;

	public Message<String> execute(Message<String> message) {
		log.info("Inside PaalanConnectService/execute()");

		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject dataJson = null;
		JSONObject reqDataJson = null;

		String name = null;
		String mobileNo = null;
		String email = null;
		String connectMessage = null;
		String response = null;

		HashMap<String, String> reqDataMap = null;

		try {
			dataJson = new JSONObject(jsonData);
			reqDataJson = dataJson.getJSONObject(ApplicationConstant.DATA);

			if (reqDataJson.has(ApplicationConstant.NAME)) {
				name = reqDataJson.getString(ApplicationConstant.NAME);
			}
			
			if (reqDataJson.has(ApplicationConstant.EMAIL_ID)) {
				email = reqDataJson.getString(ApplicationConstant.EMAIL_ID);
			}
			
			if (reqDataJson.has(ApplicationConstant.MOBILE_NO)) {
				mobileNo = reqDataJson.getString(ApplicationConstant.MOBILE_NO);
			}
			
			if (reqDataJson.has(ApplicationConstant.MESSAGE)) {
				connectMessage = reqDataJson.getString(ApplicationConstant.MESSAGE);
			}

			if (log.isInfoEnabled()) {
				log.info("Message Headers is : " + messageHeaders);
				log.info("NAME is : " + name);
				log.info("EMAIL_ID is : " + email);
				log.info("MOBILE_NO is : " + mobileNo);
				log.info("MESSAGE is : " + connectMessage);
				

			}

			reqDataMap = getReqDataMap(name,email,mobileNo,connectMessage);

			response = appSyncService.submitMessage(reqDataMap);

			return MessageBuilder.withPayload(response).build();

		} catch (Exception ex) {
			log.error("Exception in OrgProfileService/execute() " + ex.getMessage(), ex.getCause());

		}

		return null;

	}

	private HashMap<String, String> getReqDataMap(String orgId, String email, String mobileNo, String message) {

		HashMap<String, String> reqDataMap = new HashMap<String, String>();

		reqDataMap.put(ApplicationConstant.NAME, orgId);
		reqDataMap.put(ApplicationConstant.EMAIL_ID, email);
		reqDataMap.put(ApplicationConstant.MOBILE_NO, mobileNo);
		reqDataMap.put(ApplicationConstant.MESSAGE, message);

		return reqDataMap;
	}
}
