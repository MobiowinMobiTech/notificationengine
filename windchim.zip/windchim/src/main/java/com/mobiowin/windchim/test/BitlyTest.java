package com.mobiowin.windchim.test;

import java.net.URL;

import com.rosaloves.bitlyj.Bitly;
import com.rosaloves.bitlyj.Bitly.Provider;

public class BitlyTest {

	public static final String BITLY_USER = "ramancmss";

	public static final String BITLY_APIKEY = "R_0f021677146343ffb0326b97cebcd08a";

	private static Provider bitly;

	/**
	 *  
	 */
	private BitlyTest() {
		super();
	}

	private static Provider getBitLyProvider() {
		if (bitly == null) {
			bitly = Bitly.as(BITLY_USER, BITLY_APIKEY);
		}
		return bitly;
	}

	public static String shortenUrl(String longUrl) {
		return getBitLyProvider().call(Bitly.shorten(longUrl)).getShortUrl();
	}

	public static String shortenUrl(URL longUrl) {
		return getBitLyProvider().call(Bitly.shorten(longUrl.toExternalForm())).getShortUrl();
	}

	public static void main(String[] args) {
		
		try {
			URL url = new URL("https://124.124.0.5:9090/magicxpi4_1/MGrqispi.dll?appname=IFSRural_Collection_API&prgname=HTTP&arguments=-AHTTP_Rural_Collection_API_Enc%23CallBackToFullerton");
			System.out.println("<---------->" + BitlyTest.shortenUrl(url));
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
}
