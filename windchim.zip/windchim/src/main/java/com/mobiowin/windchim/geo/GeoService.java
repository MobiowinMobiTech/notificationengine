package com.mobiowin.windchim.geo;

import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.mobiowin.windchim.bean.ReverseGeoAddressBean;

@Service("geoService")
@EnableAsync
@Component
public class GeoService implements IGeoService {
	private Log log = LogFactory.getLog(this.getClass());

	@Async
	public List<String> getReverseGeoDetails(String latitude, String longitude) {
		String address = null;
		String gURL = "http://maps.google.com/maps/api/geocode/xml?latlng=" + latitude + "," + longitude
				+ "&sensor=true";
		List<ReverseGeoAddressBean> reverseGeoAddressList = null;

		try {
			DocumentBuilderFactory df = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = df.newDocumentBuilder();
			Document dom = db.parse(gURL);
			Element docEl = dom.getDocumentElement();
			NodeList nl = docEl.getElementsByTagName("result");

			if (nl != null && nl.getLength() > 0) {
				address = ((Element) nl.item(0)).getElementsByTagName("formatted_address").item(0).getTextContent();
				log.info("Address : " + address);
				System.out.println("Address : " + address);

				reverseGeoAddressList = getDetailedAddress(address);
			}
		} catch (Exception ex) {
			address = "Err";
		}

		log.info("Address is :" + address);
		return null;
	}

	private List<ReverseGeoAddressBean> getDetailedAddress(String address) {
		log.info("Inside ReverseGeoUtility/getDetailedAddress()");

		String[] addressArray = address.split(",");

		System.out.println("addressArray : " + addressArray.length);

		List<String> itemList = new ArrayList<String>();

		for (String item : addressArray) {
			itemList.add(item);
		}

		for (String str : itemList) {
			System.out.println(" <  > : " + str);
		}
		System.out.println(itemList.size());
		return null;
	}
	
	public static void main(String[] args) {
		
		GeoService geoService = new GeoService();
		geoService.getReverseGeoDetails("19.1863001", "72.8358083");
	}

}
