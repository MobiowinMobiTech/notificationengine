package com.mobiowin.windchim.notification;

import java.util.HashMap;

public interface IFCMIntegrationService {

	String sendFcmNotificationMessage(HashMap<String, String> notificationDataMap);
}
