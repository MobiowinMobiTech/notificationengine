package com.mobiowin.windchim.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "student_homework_master", catalog = "windchimp")
public class StudentHomeworkMaster implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private String id;

	@Column(name = "homework_id")
	private String homeworkId;

	@Column(name = "branch_id")
	private String branchId;

	@Column(name = "class_name")
	private String className;

	@Column(name = "homework_discription")
	private String homeworkDiscription;

	@Column(name = "homework_dt")
	private Date homeworkDt;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_dt")
	private Date createDt;

	@Column(name = "modified_by")
	private String modifiedBy;

	@Column(name = "modified_dt")
	private Date modifyDt;

	@Column(name = "del_flag")
	private String deleteFlag;

	public StudentHomeworkMaster() {
		super();

	}

	public StudentHomeworkMaster(String id, String homeworkId, String branchId, String className,
			String homeworkDiscription, Date homeworkDt, String createdBy, Date createDt, String modifiedBy,
			Date modifyDt, String deleteFlag) {
		super();
		this.id = id;
		this.homeworkId = homeworkId;
		this.branchId = branchId;
		this.className = className;
		this.homeworkDiscription = homeworkDiscription;
		this.homeworkDt = homeworkDt;
		this.createdBy = createdBy;
		this.createDt = createDt;
		this.modifiedBy = modifiedBy;
		this.modifyDt = modifyDt;
		this.deleteFlag = deleteFlag;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getHomeworkId() {
		return homeworkId;
	}

	public void setHomeworkId(String homeworkId) {
		this.homeworkId = homeworkId;
	}

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public Date getHomeworkDt() {
		return homeworkDt;
	}

	public void setHomeworkDt(Date homeworkDt) {
		this.homeworkDt = homeworkDt;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifyDt() {
		return modifyDt;
	}

	public void setModifyDt(Date modifyDt) {
		this.modifyDt = modifyDt;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	public String getHomeworkDiscription() {
		return homeworkDiscription;
	}

	public void setHomeworkDiscription(String homeworkDiscription) {
		this.homeworkDiscription = homeworkDiscription;
	}

	@Override
	public String toString() {
		return "StudentHomeworkMaster [id=" + id + ", homeworkId=" + homeworkId + ", branchId=" + branchId
				+ ", className=" + className + ", homeworkDiscription=" + homeworkDiscription + ", homeworkDt="
				+ homeworkDt + ", createdBy=" + createdBy + ", createDt=" + createDt + ", modifiedBy=" + modifiedBy
				+ ", modifyDt=" + modifyDt + ", deleteFlag=" + deleteFlag + "]";
	}

}
