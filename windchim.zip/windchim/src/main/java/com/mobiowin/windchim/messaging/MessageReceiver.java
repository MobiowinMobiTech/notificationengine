package com.mobiowin.windchim.messaging;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.windchim.commons.ApplicationConstant;

@Service("messageReceiver")
@Component
public class MessageReceiver implements IMessageReceiver {

	private Log log = LogFactory.getLog(getClass());

	public Message<String> recieve(Message<String> message) {

		log.info("Inside SimpleMessageReceiver / recieve().....");

		String entity = null;
		String type = null;
		String action = null;

		try {
			Map<String, Object> messageHeader = message.getHeaders();

			String messageData = message.getPayload();
			JSONObject messageObj = new JSONObject(messageData);
			entity = (String) messageObj.get(ApplicationConstant.ENTITY);
			type = (String) messageObj.get(ApplicationConstant.TYPE);
			action = (String) messageObj.get(ApplicationConstant.ACTON);

			if (log.isInfoEnabled()) {
				log.info("Request Message header is ------------ > " + messageHeader);
				log.info("Request Message entity is ------------ > " + entity);
				log.info("Request Message type is ------------ > " + type);
				log.info("Request Message action is ------------ > " + action);
			}

			return MessageBuilder.withPayload(message.getPayload())
					.copyHeaders(message.getHeaders())
					.setHeader(ApplicationConstant.ENTITY, entity)
					.setHeader(ApplicationConstant.TYPE, type)
					.setHeader(ApplicationConstant.TYPE_ACTION, type+"_"+action).build();

		} catch (JSONException e) {
			log.error("Exception in JSON Message building ..... " + e.getMessage(), e.getCause());
			e.printStackTrace();
			return null;
		} catch (Exception ex) {
			log.error("Exception in MessageReceiver / recieve() " + ex.getMessage(), ex.getCause());
			return null;
		}

	}

}
