package com.mobiowin.windchim.test;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.JSONObject;

public class DateUtility {
	public static String convertToDateTime(String date) throws ParseException {
		if ("".equals(date)) {
			return null;
		}

		SimpleDateFormat fromDateFormat = new SimpleDateFormat("dd/MMM/yyyy");

		Date fromDate = fromDateFormat.parse(date);

		SimpleDateFormat toDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.000Z"); // 2011-12-12T12:12:12.000Z
																							// //2012-00-04
																							// 12:00:00.000+0530

		String toDate = toDateFormat.format(fromDate);

		String formattedDate = formatToWebServiceDate(toDate);

		return formattedDate;
	}

	public static String formatToWebServiceDate(String inputDate) {
		String formattedDate = inputDate.replace(" ", "T").replace("+0530", "Z");

		String monthString = formattedDate.substring(5, 7);

		Integer month = Integer.parseInt(monthString);

		System.out.println("month : " + month);

		return formattedDate.substring(0, 5) + formattedDate.substring(5, 7) + formattedDate.substring(7);
	}

	public static String convertToDate(String dateFromWebService) throws ParseException {

		if ("".equals(dateFromWebService)) {
			return "";
		} else {
			SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat outputDateFormat = new SimpleDateFormat("dd/MMM/yyyy");
			Date date = inputDateFormat.parse(dateFromWebService);
			String outputDate = outputDateFormat.format(date);
			return outputDate.toUpperCase();
		}
	}

	public static void convertDate(JSONObject dataJson, String dateField) {
		try {
			Object dateFieldValue = dataJson.get(dateField);

			if (dateFieldValue != null) {
				String convertedDate = convertToDateTime(dateFieldValue.toString());

				if (convertedDate != null) {
					dataJson.put(dateField, convertedDate);
				}
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text>
	 * <li>post-condition <enter text>
	 *
	 * @param string
	 * @return
	 *
	 * @author saylee
	 * @createdOn Sep 25, 2012
	 * @modifiedOn Sep 25, 2012
	 * 
	 */
	public static String convertToDateTimeIST(String date, String time) throws ParseException {

		if ("".equals(date)) {
			return null;
		}
		String formattedDate = new String();
		if (null != time && !("".equals(time))) {

			SimpleDateFormat fromDateFormat = new SimpleDateFormat("dd/MMM/yyyy HH:mm:ss");

			Date fromDate = fromDateFormat.parse(date + " " + time);

			SimpleDateFormat toDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.000Z"); // 2011-12-12T12:12:12.000Z
																								// //2012-00-04
																								// 12:00:00.000+0530

			String toDate = toDateFormat.format(fromDate);

			formattedDate = formatToWebServiceDateIST(toDate);
		} else {
			formattedDate = convertToDateTime(date);
		}

		return formattedDate;

	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text>
	 * <li>post-condition <enter text>
	 *
	 * @param toDate
	 * @return
	 *
	 * @author saylee
	 * @createdOn Sep 25, 2012
	 * @modifiedOn Sep 25, 2012
	 * 
	 */
	private static String formatToWebServiceDateIST(String inputDate) {
		String formattedDate = inputDate.replace(" ", "T").replace("+0530", "");

		String monthString = formattedDate.substring(5, 7);

		Integer month = Integer.parseInt(monthString);

		System.out.println("month : " + month);

		return formattedDate.substring(0, 5) + formattedDate.substring(5, 7) + formattedDate.substring(7);
	}

	/*public static void main(String args[])
	{
		getTimeStamp();

	   
	}*/
	
	/*public static void main (String [] args) {
	       //long currentDateTime = System.currentTimeMillis();
	        syncDateparser("1485083154030");
	   }*/

	public static String syncDateparser(String lastSyncDate) {
			long currentDateTime = Long.parseLong(lastSyncDate);
	       Date currentDate = new Date(currentDateTime);

	       DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	       System.out.println(dateFormat.format(currentDate));
	       
	       String str = dateFormat.format(currentDate);
	       
	       return str;
	}

	public static Timestamp getTimeStamp() 
	{
		java.util.Date utilDate = new java.util.Date();
		java.sql.Timestamp sq = new java.sql.Timestamp(utilDate.getTime());
		System.out.println("" + sq);
		return sq;
		//System.out.println(sq); //this will print the milliseconds as the toString() has been written in that format

		/*SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return sdf.format(sq);*/
	}
	
	
	
	
}
