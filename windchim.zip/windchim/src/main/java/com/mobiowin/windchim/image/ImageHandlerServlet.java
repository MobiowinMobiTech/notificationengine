package com.mobiowin.windchim.image;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.mobiowin.windchim.commons.ApplicationConstant;

/**
 * Servlet implementation class GenniImageServlet
 */

public class ImageHandlerServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	
	private Log log = LogFactory.getLog(this.getClass());
	
	public ImageHandlerServlet()
	{
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@SuppressWarnings("unchecked")
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException
	{

		ApplicationContext applicationContext = WebApplicationContextUtils
				.getRequiredWebApplicationContext(getServletContext());

		
		String entity = request.getParameter("entity");
		
		if(entity.equals("slider"))
		{
			Map<String, List<String>> geeniImageConfig = applicationContext
					.getBean(ApplicationConstant.IMAGE_CONFIG, Map.class);
			
			List<String> imageBasePath = (List<String>) geeniImageConfig.get("SLIDER_IMG_BASE_PATH");
			
			String imageCode = request.getParameter(ApplicationConstant.IMAGE_SERVLET_IMAGE_PARAM);
			StringBuilder imagePath = null;
			
			
			if(log.isInfoEnabled())
			{
				log.info("Image Base Path is : " + imageBasePath.get(0));
				log.info("Image Code is 	 : " + imageCode);
			}
			
			
			
			if(null != imageCode)
			{
				imagePath = new StringBuilder();
				imagePath.append(imageBasePath.get(0).trim());
				imagePath.append(imageCode.trim());			 
			}
			
			
			
			log.info("RealImage Path is : " + imagePath.toString());
			
			displayImage(request, response, imagePath);
		}
		
		if(entity.equals("event"))
		{
			Map<String, List<String>> geeniImageConfig = applicationContext
					.getBean(ApplicationConstant.IMAGE_CONFIG, Map.class);
			
			List<String> imageBasePath = (List<String>) geeniImageConfig.get("EVENT_BASE_PATH");
			
			String imageCode = request.getParameter(ApplicationConstant.IMAGE_SERVLET_IMAGE_PARAM);
			StringBuilder imagePath = null;
			
			
			if(log.isInfoEnabled())
			{
				log.info("Image Base Path is : " + imageBasePath.get(0));
				log.info("Image Code is 	 : " + imageCode);
			}
			
			
			
			if(null != imageCode)
			{
				imagePath = new StringBuilder();
				imagePath.append(imageBasePath.get(0).trim());
				imagePath.append(imageCode.trim());
				//imagePath.append(ApplicationConstant.FLASH_IAMGE_FORMAT);			 
			}
			
			
			
			log.info("RealImage Path is : " + imagePath.toString());
			
			displayImage(request, response, imagePath);
		}
		
		
		

	}

	private void displayImage(HttpServletRequest request,
			HttpServletResponse response, StringBuilder imagePath)
	{
		FileInputStream fin = null;
		try
		{
			fin = new FileInputStream(imagePath.toString());
			byte[] bytes = new byte[1024];
			while (fin.read(bytes) != -1)
			{
				response.getOutputStream().write(bytes);
			}

		}
		catch (Exception e)
		{
			defaultImage(request, response);
			log.info("exception in image servlet is : " + e.getMessage());
		}
	}

	private void defaultImage(HttpServletRequest request,
			HttpServletResponse response)
	{
		ApplicationContext applicationContext = WebApplicationContextUtils
				.getRequiredWebApplicationContext(getServletContext());
		
		@SuppressWarnings("unchecked")
		Map<String, List<String>> businessImageConfig = applicationContext
				.getBean(ApplicationConstant.IMAGE_CONFIG, Map.class);
		
		List<String> businessDefaultImgBaseConfig = (List<String>) businessImageConfig.get("DEFAULT_BUSINESS_IMAGE_CONFIG");
		
		StringBuilder defaultImagePath = new StringBuilder();
		defaultImagePath.append(businessDefaultImgBaseConfig.get(0).trim());
		defaultImagePath.append(businessDefaultImgBaseConfig.get(1).trim());
		defaultImagePath.append(ApplicationConstant.FLASH_IAMGE_FORMAT);
		
		
		displayImage(request, response, defaultImagePath);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException
	{
		doGet(request, response);
	}

}
