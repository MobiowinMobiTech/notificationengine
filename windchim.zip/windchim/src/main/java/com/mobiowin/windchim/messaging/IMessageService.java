package com.mobiowin.windchim.messaging;

import org.springframework.messaging.Message;

public interface IMessageService {
	public abstract Message<String> execute(Message<String> message);
}
