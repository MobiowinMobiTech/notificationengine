package com.mobiowin.windchim.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "branch_master", catalog = "windchimp")
public class BranchMasterBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private String id;

	@Column(name = "branch_id")
	private String branchId;

	@Column(name = "branch_address")
	private String address;

	@Column(name = "latitude")
	private String latitude;

	@Column(name = "longitude")
	private String longitude;

	@Column(name = "branch_type")
	private String branchType;

	@Column(name = "email_id")
	private String emailId;

	@Column(name = "mobile_no")
	private String mobileNo;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_dt")
	private Date createDt;

	@Column(name = "modified_by")
	private String modifiedBy;

	@Column(name = "modified_dt")
	private Date modifyDt;

	@Column(name = "del_flag")
	private String deleteFlag;

	public BranchMasterBean() {
		super();
	}

	public BranchMasterBean(String id, String branchId, String address, String latitude, String longitude,
			String branchType, String emailId, String mobileNo, String createdBy, Date createDt, String modifiedBy,
			Date modifyDt, String deleteFlag) {
		super();
		this.id = id;
		this.branchId = branchId;
		this.address = address;
		this.latitude = latitude;
		this.longitude = longitude;
		this.branchType = branchType;
		this.emailId = emailId;
		this.mobileNo = mobileNo;
		this.createdBy = createdBy;
		this.createDt = createDt;
		this.modifiedBy = modifiedBy;
		this.modifyDt = modifyDt;
		this.deleteFlag = deleteFlag;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getBranchType() {
		return branchType;
	}

	public void setBranchType(String branchType) {
		this.branchType = branchType;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifyDt() {
		return modifyDt;
	}

	public void setModifyDt(Date modifyDt) {
		this.modifyDt = modifyDt;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	@Override
	public String toString() {
		return "BranchMaster [id=" + id + ", branchId=" + branchId + ", address=" + address + ", latitude=" + latitude
				+ ", longitude=" + longitude + ", branchType=" + branchType + ", emailId=" + emailId + ", mobileNo="
				+ mobileNo + ", createdBy=" + createdBy + ", createDt=" + createDt + ", modifiedBy=" + modifiedBy
				+ ", modifyDt=" + modifyDt + ", deleteFlag=" + deleteFlag + "]";
	}

	
	
}
