package com.mobiowin.windchim.dao;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.mobiowin.windchim.bean.BranchMasterBean;
import com.mobiowin.windchim.bean.BroadcastMasterBean;
import com.mobiowin.windchim.bean.ConnectBean;
import com.mobiowin.windchim.bean.DeviceDetailBean;
import com.mobiowin.windchim.bean.EventMasterBean;
import com.mobiowin.windchim.bean.ScreenMasterBean;
import com.mobiowin.windchim.bean.SliderMasterBean;
import com.mobiowin.windchim.bean.SurveyMasterBean;
import com.mobiowin.windchim.commons.ApplicationConstant;
import com.mobiowin.windchim.test.DateUtility;

@Repository("appSyncDao")
@Component
public class AppSyncHelperDao implements IAppSyncHelperDao {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private SessionFactory sessionFactory;

	Session session = null;
	Transaction transaction = null;

	public boolean validateAppVersion(HashMap<String, String> appReqDataMap) {
		log.info("Inside AppSyncHelperDao/validateAppVersion()");

		/*
		 * select count(1) from
		 */

		return false;
	}

	public List<SliderMasterBean> syncAppBanner(String lastSyncDate) {
		List<SliderMasterBean> appBannerList = null;
		StringBuilder appBannerSyncQuery = null;
		StringBuilder appBannerSyncQueryBuilder = new StringBuilder();
		appBannerSyncQueryBuilder.append("from SliderMasterBean ");

		if (lastSyncDate.equals("0")) {
			appBannerSyncQuery = getAppBannerSyncQuery(appBannerSyncQueryBuilder);
		} else {
			appBannerSyncQuery = getAppBannerIncrementalSyncQuery(appBannerSyncQueryBuilder);
		}

		log.info("AppBannerSyncQuery is : " + appBannerSyncQuery);

		try {
			Query query = sessionFactory.openSession().createQuery(appBannerSyncQuery.toString());

			if (lastSyncDate.equals("0")) {
				query.setParameter("deleteFlag", ApplicationConstant.DEL_FLAG);
			} else {
				query.setParameter("createDt", Timestamp.valueOf(DateUtility.syncDateparser(lastSyncDate)));
				query.setParameter("modifyDt", Timestamp.valueOf(DateUtility.syncDateparser(lastSyncDate)));
				query.setParameter("deleteFlag", ApplicationConstant.DEL_FLAG);

			}

			appBannerList = query.list();

			log.info("App banner is : " + appBannerList.size());

			return appBannerList;
		} catch (HibernateException e) {
			log.error("Hibernate exception in syncAchievement() : " + e.getMessage());
			e.printStackTrace();
			return appBannerList;
		} catch (Exception ex) {
			log.error("Hibernate exception in syncAchievement() : " + ex.getMessage());
			ex.printStackTrace();
			return appBannerList;
		}
	}

	private StringBuilder getAppBannerIncrementalSyncQuery(StringBuilder orgEventSyncQueryBuilder) {
		orgEventSyncQueryBuilder.append("where ");
		orgEventSyncQueryBuilder.append("createDt > :createDt ");
		orgEventSyncQueryBuilder.append("or modifyDt > :modifyDt ");
		orgEventSyncQueryBuilder.append("and deleteFlag =:deleteFlag");
		return orgEventSyncQueryBuilder;
	}

	private StringBuilder getAppBannerSyncQuery(StringBuilder orgEventSyncQueryBuilder) {
		orgEventSyncQueryBuilder.append("where ");
		orgEventSyncQueryBuilder.append("deleteFlag =:deleteFlag");
		return orgEventSyncQueryBuilder;
	}

	public List<ScreenMasterBean> syncScreen(String lastSyncDate) {
		log.info("Inside AppSyncHelperDao/syncScreen()");

		List<ScreenMasterBean> screenMasterList = null;
		StringBuilder screenSyncQueryBuilder = new StringBuilder();
		screenSyncQueryBuilder.append("from ScreenMasterBean ");

		if (lastSyncDate.equals("0")) {
			screenSyncQueryBuilder = getScreenMasterSyncQuery(screenSyncQueryBuilder);
		} else {
			screenSyncQueryBuilder = getScreenMasterIncrementalSyncQuery(screenSyncQueryBuilder);
		}

		log.info("screenSyncQueryBuilder is : " + screenSyncQueryBuilder);

		try {
			Query query = sessionFactory.openSession().createQuery(screenSyncQueryBuilder.toString());

			if (lastSyncDate.equals("0")) {
				query.setParameter("deleteFlag", ApplicationConstant.DEL_FLAG);
			} else {
				query.setParameter("createDt", Timestamp.valueOf(DateUtility.syncDateparser(lastSyncDate)));
				query.setParameter("modifyDt", Timestamp.valueOf(DateUtility.syncDateparser(lastSyncDate)));
				query.setParameter("deleteFlag", ApplicationConstant.DEL_FLAG);

			}

			screenMasterList = query.list();

			log.info("Screen List is : " + screenMasterList.size());

			return screenMasterList;
		} catch (HibernateException e) {
			log.error("Hibernate exception in syncScreen() : " + e.getMessage());
			e.printStackTrace();
			return screenMasterList;
		} catch (Exception ex) {
			log.error("Hibernate exception in syncScreen() : " + ex.getMessage());
			ex.printStackTrace();
			return screenMasterList;
		}

	}

	private StringBuilder getScreenMasterIncrementalSyncQuery(StringBuilder screenSyncQueryBuilder) {
		screenSyncQueryBuilder.append("where ");
		screenSyncQueryBuilder.append("createDt > :createDt ");
		screenSyncQueryBuilder.append("or modifyDt > :modifyDt ");
		screenSyncQueryBuilder.append("and deleteFlag =:deleteFlag");
		return screenSyncQueryBuilder;
	}
	
	public List<BranchMasterBean> syncBranchDetails(String lastSyncDate) {
		log.info("Inside AppSyncHelperDao/syncBranchDetails()");

		List<BranchMasterBean> branchMasterList = null;
		StringBuilder branchSyncQueryBuilder = new StringBuilder();
		branchSyncQueryBuilder.append("from BranchMasterBean ");

		if (lastSyncDate.equals("0")) {
			branchSyncQueryBuilder = getScreenMasterSyncQuery(branchSyncQueryBuilder);
		} else {
			branchSyncQueryBuilder = getScreenMasterIncrementalSyncQuery(branchSyncQueryBuilder);
		}

		log.info("branchSyncQueryBuilder is : " + branchSyncQueryBuilder);

		try {
			Query query = sessionFactory.openSession().createQuery(branchSyncQueryBuilder.toString());

			if (lastSyncDate.equals("0")) {
				query.setParameter("deleteFlag", ApplicationConstant.DEL_FLAG);
			} else {
				query.setParameter("createDt", Timestamp.valueOf(DateUtility.syncDateparser(lastSyncDate)));
				query.setParameter("modifyDt", Timestamp.valueOf(DateUtility.syncDateparser(lastSyncDate)));
				query.setParameter("deleteFlag", ApplicationConstant.DEL_FLAG);

			}

			branchMasterList = query.list();

			log.info("Screen List is : " + branchMasterList.size());

			return branchMasterList;
		} catch (HibernateException e) {
			log.error("Hibernate exception in syncBranchDetails() : " + e.getMessage());
			e.printStackTrace();
			return branchMasterList;
		} catch (Exception ex) {
			log.error("Hibernate exception in syncBranchDetails() : " + ex.getMessage());
			ex.printStackTrace();
			return branchMasterList;
		}
	}

	private StringBuilder getScreenMasterSyncQuery(StringBuilder screenSyncQueryBuilder) {
		screenSyncQueryBuilder.append("where ");
		screenSyncQueryBuilder.append("deleteFlag =:deleteFlag");
		return screenSyncQueryBuilder;
	}

	public List<BroadcastMasterBean> syncBroadcastTopic(String lastSyncDate) {

		log.info("Inside AppSyncHelperDao/syncScreen()");

		List<BroadcastMasterBean> broadcastTopicMasterList = null;
		StringBuilder broadcastSyncQueryBuilder = new StringBuilder();
		broadcastSyncQueryBuilder.append("from BroadcastMasterBean ");

		if (lastSyncDate.equals("0")) {
			broadcastSyncQueryBuilder = getScreenMasterSyncQuery(broadcastSyncQueryBuilder);
		} else {
			broadcastSyncQueryBuilder = getScreenMasterIncrementalSyncQuery(broadcastSyncQueryBuilder);
		}

		log.info("broadcastSyncQueryBuilder is : " + broadcastSyncQueryBuilder);

		try {
			Query query = sessionFactory.openSession().createQuery(broadcastSyncQueryBuilder.toString());

			if (lastSyncDate.equals("0")) {
				query.setParameter("deleteFlag", ApplicationConstant.DEL_FLAG);
			} else {
				query.setParameter("createDt", Timestamp.valueOf(DateUtility.syncDateparser(lastSyncDate)));
				query.setParameter("modifyDt", Timestamp.valueOf(DateUtility.syncDateparser(lastSyncDate)));
				query.setParameter("deleteFlag", ApplicationConstant.DEL_FLAG);
			}

			broadcastTopicMasterList = query.list();

			log.info("Broadcast topic list is : " + broadcastTopicMasterList.size());

			return broadcastTopicMasterList;
		} catch (HibernateException e) {
			log.error("Hibernate exception in syncBroadcastTopic() : " + e.getMessage());
			e.printStackTrace();
			return broadcastTopicMasterList;
		} catch (Exception ex) {
			log.error("Hibernate exception in syncBroadcastTopic() : " + ex.getMessage());
			ex.printStackTrace();
			return broadcastTopicMasterList;
		}
	}

	public boolean isUserExist(DeviceDetailBean deviceDetailBean) 
	{
		log.info("Inside AppSyncHelperDao/isUserExist()");

		StringBuilder userCheckQueryBuilder = new StringBuilder();
		userCheckQueryBuilder.append("from DeviceDetailBean ");

		StringBuilder userCheckQuery = getUserCheckQuery(userCheckQueryBuilder);

		log.info("userCheckQuery is : " + userCheckQuery);

		try {
			Query query = sessionFactory.openSession().createQuery(userCheckQuery.toString());
			query.setParameter("deviceId", deviceDetailBean.getDeviceId());
			query.setParameter("deleteFlag", deviceDetailBean.getDeleteFlag());

			List<DeviceDetailBean> deviceDeviceList = query.list();

			log.info("DeviceList is : " + deviceDeviceList.size());

			if (deviceDeviceList.size() > 0) {
				return true;
			}

			return false;
		} catch (HibernateException e) {
			log.error("Hibernate exception in isUserExist() : " + e.getMessage());
			e.printStackTrace();
			return false;
		} catch (Exception ex) {
			log.error("Hibernate exception in isUserExist() : " + ex.getMessage());
			ex.printStackTrace();
			return false;
		}
	}

	private StringBuilder getUserCheckQuery(StringBuilder userCheckQueryBuilder) {
		userCheckQueryBuilder.append("where deviceId = :deviceId and deleteFlag =:deleteFlag");
		return userCheckQueryBuilder;
	}

	public String submitUser(DeviceDetailBean deviceDetailBean) 
	{
		log.info("Inside AppSyncHelperDao/submitUser()");
		
		log.info("deviceDetailBean : " + deviceDetailBean);

		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			session.save(deviceDetailBean);
			session.flush();
			transaction.commit();

			return ApplicationConstant.TRUE;
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
			log.error("Exception in registerOrg : " + e.getMessage(), e.getCause());
			return ApplicationConstant.FALSE;
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			log.error("Exception in registerOrg : " + ex.getMessage(), ex.getCause());
			return ApplicationConstant.FALSE;
		}
		
	}

	public String updateUser(DeviceDetailBean deviceDetailBean) 
	{
		log.info("Inside AppSyncHelperDao/updateUser()");

		StringBuilder deviceQueryBuilder = null;
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			deviceQueryBuilder = new StringBuilder();
			deviceQueryBuilder.append("update DeviceDetailBean ");
			deviceQueryBuilder = fetchDeviceUpdateBuilder(deviceQueryBuilder);

			log.info("device Detail Bean is : " + deviceDetailBean);
			log.info("device Detail Bean query is : " + deviceQueryBuilder.toString());

			Query query = session.createQuery(deviceQueryBuilder.toString());

			query.setParameter("notificationId", deviceDetailBean.getNotificationId());
			query.setParameter("modifiedBy", deviceDetailBean.getModifiedBy());
			query.setParameter("modifyDt", deviceDetailBean.getModifyDt());
			query.setParameter("deviceId", deviceDetailBean.getDeviceId());
			query.setParameter("deleteFlag", deviceDetailBean.getDeleteFlag());

			int updateStatus = query.executeUpdate();

			log.info("Device details Status : " + updateStatus);

			session.flush();
			transaction.commit();

			return ApplicationConstant.TRUE;
		} catch (Exception e) {
			log.error("Exception in updating event : " + e.getMessage(), e.getCause());
			e.printStackTrace();

			return ApplicationConstant.FALSE;

		}
	}

	private StringBuilder fetchDeviceUpdateBuilder(StringBuilder deviceQueryBuilder) {
		deviceQueryBuilder.append("set notificationId = :notificationId ,");
		deviceQueryBuilder.append("modifiedBy = :modifiedBy ,");
		deviceQueryBuilder.append("modifyDt = :modifyDt ");
		deviceQueryBuilder.append("where deviceId = :deviceId and deleteFlag =:deleteFlag");
		return deviceQueryBuilder;
		
	}

	public String submitMessage(ConnectBean connectBean) {
		log.info("Inside submitMessage/submitProfile()");

		log.info("connect Bean : " + connectBean);

		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			session.save(connectBean);
			session.flush();
			transaction.commit();

			return ApplicationConstant.TRUE;
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
			log.error("Exception in submitProfile : " + e.getMessage(), e.getCause());
			return ApplicationConstant.FALSE;
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			log.error("Exception in submitProfile : " + ex.getMessage(), ex.getCause());
			return ApplicationConstant.FALSE;
		}
		
	}

	public List<EventMasterBean> syncEvent(EventMasterBean eventMasterBean, String lastSyncDate) {
		log.info("Inside CoreOrgHelperDao/syncEvent()");

		List<EventMasterBean> eventList = null;
		StringBuilder eventSyncQueryBuilder = new StringBuilder();
		eventSyncQueryBuilder.append("from EventMasterBean ");


		if (lastSyncDate.equals("0"))
		{
			eventSyncQueryBuilder = getEventSyncQuery(eventSyncQueryBuilder);
		} else {
			eventSyncQueryBuilder = getEventIncrementalSyncQuery(eventSyncQueryBuilder);
		}
		
		log.info("eventSyncQueryBuilder is : " + eventSyncQueryBuilder);

		try {
			Query query = sessionFactory.openSession().createQuery(eventSyncQueryBuilder.toString());
			
			if (lastSyncDate.equals("0")) 
			{
				query.setParameter("deleteFlag", eventMasterBean.getDeleteFlag());
			}
			else {
				query.setParameter("createDt", Timestamp.valueOf(DateUtility.syncDateparser(lastSyncDate)));
				query.setParameter("modifyDt", Timestamp.valueOf(DateUtility.syncDateparser(lastSyncDate)));
				query.setParameter("deleteFlag", eventMasterBean.getDeleteFlag());

			}
			

			eventList = query.list();

			log.info(" event List is : " + eventList.size());

			return eventList;
		} catch (HibernateException e) {
			log.error("Hibernate exception in syncEvent() : " + e.getMessage());
			e.printStackTrace();
			return eventList;
		} catch (Exception ex) {
			log.error("Hibernate exception in syncEvent() : " + ex.getMessage());
			ex.printStackTrace();
			return eventList;
		}
	}
	
	private StringBuilder getEventIncrementalSyncQuery(StringBuilder eventSyncQueryBuilder) {
		eventSyncQueryBuilder.append("where  ");
		eventSyncQueryBuilder.append("createDt > :createDt ");
		eventSyncQueryBuilder.append("or modifyDt > :modifyDt ");
		eventSyncQueryBuilder.append("and deleteFlag =:deleteFlag");
		return eventSyncQueryBuilder;
	}
	
	private StringBuilder getEventSyncQuery(StringBuilder eventSyncQueryBuilder) {
		eventSyncQueryBuilder.append("where ");
		eventSyncQueryBuilder.append("deleteFlag =:deleteFlag");
		return eventSyncQueryBuilder;
	}

	public List<EventMasterBean> syncEventById(EventMasterBean eventMasterBean) {
		log.info("Inside CoreOrgHelperDao/syncEvent()");

		List<EventMasterBean> eventList = null;
		StringBuilder eventSyncByIdQueryBuilder = new StringBuilder();
		eventSyncByIdQueryBuilder.append("from EventMasterBean ");
		eventSyncByIdQueryBuilder.append("where eventId = :eventId ");
		eventSyncByIdQueryBuilder.append("and deleteFlag =:deleteFlag ");

		
		
		log.info("eventSyncByIdQueryBuilder is : " + eventSyncByIdQueryBuilder);

		try {
			Query query = sessionFactory.openSession().createQuery(eventSyncByIdQueryBuilder.toString());
			query.setParameter("eventId", eventMasterBean.getEventId());
			query.setParameter("deleteFlag", eventMasterBean.getDeleteFlag());
			eventList = query.list();

			log.info(" event List is : " + eventList.size());

			return eventList;
		} catch (HibernateException e) {
			log.error("Hibernate exception in syncEventById() : " + e.getMessage());
			e.printStackTrace();
			return eventList;
		} catch (Exception ex) {
			log.error("Hibernate exception in syncEventById() : " + ex.getMessage());
			ex.printStackTrace();
			return eventList;
		}
	}

	public String submitSurveyMessage(SurveyMasterBean surveyMasterBean) {
		log.info("Inside submitMessage/submitSurveyMessage()");

		log.info("surveyMasterBean  : " + surveyMasterBean);

		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			session.save(surveyMasterBean);
			session.flush();
			transaction.commit();

			return ApplicationConstant.TRUE;
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
			log.error("Exception in submitSurveyMessage : " + e.getMessage(), e.getCause());
			return ApplicationConstant.FALSE;
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			log.error("Exception in submitSurveyMessage : " + ex.getMessage(), ex.getCause());
			return ApplicationConstant.FALSE;
		}
	}

	


}
