package com.mobiowin.windchim.service.app;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.windchim.commons.ApplicationConstant;
import com.mobiowin.windchim.messaging.IMessageService;
import com.mobiowin.windchim.service.helper.IAppSyncHelperServie;

@Service("versionControlService")
@Component
public class ApplicationVerisonCheckService implements IMessageService {
	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private IAppSyncHelperServie appSyncService;

	
	public Message<String> execute(Message<String> message) {
		log.info("inside ApplicationVerisonCheckService/execute()");

		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject appReqJson = null;
		JSONObject appReqDataJson = null;
		String appVerison = null;
		String response = null;

		try {
			appReqJson = new JSONObject(jsonData);
			appReqDataJson = appReqJson.getJSONObject(ApplicationConstant.DATA);

			if (appReqDataJson.has(ApplicationConstant.APP_VERSION)) {
				appVerison = appReqDataJson
						.getString(ApplicationConstant.APP_VERSION);
			}

			if (log.isInfoEnabled()) {
				log.info("Message Headers : " + messageHeaders);
				log.info("App version is : " + appVerison);
			}

			HashMap<String, String> appReqDataMap = getAppReqDataMap(appVerison);

			boolean isValid = appSyncService.checkAppversion(appReqDataMap);
			
			log.info("Is valid : " + isValid);

			if (isValid) 
			{
				response = appSyncService.generateSuccessResponse();
				return MessageBuilder.withPayload(response).build();
			} 
			else 
			{
				response = appSyncService.generateErrorResponse();
				return MessageBuilder.withPayload(response).build();
			}

		} catch (JSONException e) {
			log.error("Exception in json parsing : " + e.getMessage());
			e.printStackTrace();
		} catch (Exception ex) {
			log.error("Exception in ApplicationVerisonCheckService : "
					+ ex.getMessage());
		}

		return null;
	}

	private HashMap<String, String> getAppReqDataMap(String appVerison) {
		HashMap<String, String> appReqDataMap = new HashMap<String, String>();
		appReqDataMap.put(ApplicationConstant.APP_VERSION, appVerison);
		return appReqDataMap;
	}

}
