package com.mobiowin.windchim.service.helper;

import java.util.HashMap;

public interface IAppSyncHelperServie {

	

	boolean checkAppversion(HashMap<String, String> appReqDataMap);

	String syncApplciationData();

	String generateSuccessResponse();

	String generateErrorResponse();

	String submitDeviceDetails(HashMap<String, String> deviceDetailMap);

	String appConfigSync(HashMap<String, String> reqDataMap);

	String submitMessage(HashMap<String, String> reqDataMap);

	String syncEvent(HashMap<String, String> reqDataMap);

	String submitLeadMessage(HashMap<String, String> reqDataMap);

	

}
