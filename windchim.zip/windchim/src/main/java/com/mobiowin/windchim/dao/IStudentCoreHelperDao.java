package com.mobiowin.windchim.dao;

import java.util.List;

import com.mobiowin.windchim.bean.StudentHomeworkMaster;
import com.mobiowin.windchim.bean.StudentNotificationBean;
import com.mobiowin.windchim.bean.StudentProfileBean;
import com.mobiowin.windchim.bean.StudentRegistrationBean;

public interface IStudentCoreHelperDao {

	List<StudentRegistrationBean> validateLogin(StudentRegistrationBean registrationBean);

	List<StudentProfileBean> fetchStudentProfile(StudentProfileBean studentProfileBean);

	boolean isUserExist(StudentNotificationBean studentNotificationBean);

	String submitUser(StudentNotificationBean studentNotificationBean);

	String updateUser(StudentNotificationBean studentNotificationBean);

	List<StudentHomeworkMaster> syncHomeworkById(StudentHomeworkMaster studentHomeworkMaster);

	List<StudentHomeworkMaster> syncHomeworkList(StudentHomeworkMaster studentHomeworkMaster, String string);

}
