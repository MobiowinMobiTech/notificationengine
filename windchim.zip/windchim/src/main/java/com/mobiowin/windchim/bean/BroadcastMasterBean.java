package com.mobiowin.windchim.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "broadcast_topic_master", catalog = "windchimp")
public class BroadcastMasterBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private String id;

	@Column(name = "broadcast_id")
	private String broadcastId;

	@Column(name = "broadcast_topic_name")
	private String broadcastName;

	@Column(name = "broadcast_topic")
	private String broadcastTopic;

	@Column(name = "broadcast_topic_discription")
	private String discription;

	@Column(name = "others")
	private String others;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_dt")
	private Date createDt;

	@Column(name = "modified_by")
	private String modifiedBy;

	@Column(name = "modified_dt")
	private Date modifyDt;

	@Column(name = "del_flag")
	private String deleteFlag;

	public BroadcastMasterBean() {
		super();
	}


	public BroadcastMasterBean(String id, String broadcastId, String broadcastName, String broadcastTopic,
			String discription, String others, String createdBy, Date createDt, String modifiedBy, Date modifyDt,
			String deleteFlag) {
		super();
		this.id = id;
		this.broadcastId = broadcastId;
		this.broadcastName = broadcastName;
		this.broadcastTopic = broadcastTopic;
		this.discription = discription;
		this.others = others;
		this.createdBy = createdBy;
		this.createDt = createDt;
		this.modifiedBy = modifiedBy;
		this.modifyDt = modifyDt;
		this.deleteFlag = deleteFlag;
	}


	

	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getBroadcastId() {
		return broadcastId;
	}


	public void setBroadcastId(String broadcastId) {
		this.broadcastId = broadcastId;
	}


	public String getBroadcastName() {
		return broadcastName;
	}


	public void setBroadcastName(String broadcastName) {
		this.broadcastName = broadcastName;
	}


	public String getBroadcastTopic() {
		return broadcastTopic;
	}


	public void setBroadcastTopic(String broadcastTopic) {
		this.broadcastTopic = broadcastTopic;
	}


	public String getDiscription() {
		return discription;
	}


	public void setDiscription(String discription) {
		this.discription = discription;
	}


	public String getOthers() {
		return others;
	}


	public void setOthers(String others) {
		this.others = others;
	}


	public String getCreatedBy() {
		return createdBy;
	}


	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	public Date getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}


	public String getModifiedBy() {
		return modifiedBy;
	}


	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}


	public Date getModifyDt() {
		return modifyDt;
	}


	public void setModifyDt(Date modifyDt) {
		this.modifyDt = modifyDt;
	}


	public String getDeleteFlag() {
		return deleteFlag;
	}


	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}


	@Override
	public String toString() {
		return "BroadcastMasterBean [id=" + id + ", broadcastId=" + broadcastId + ", broadcastName=" + broadcastName
				+ ", broadcastTopic=" + broadcastTopic + ", discription=" + discription + ", others=" + others
				+ ", createdBy=" + createdBy + ", createDt=" + createDt + ", modifiedBy=" + modifiedBy + ", modifyDt="
				+ modifyDt + ", deleteFlag=" + deleteFlag + "]";
	}
	
}
