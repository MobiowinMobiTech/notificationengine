package com.mobiowin.windchim.service.helper;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.windchim.bean.BranchMasterBean;
import com.mobiowin.windchim.bean.BroadcastMasterBean;
import com.mobiowin.windchim.bean.ConnectBean;
import com.mobiowin.windchim.bean.DeviceDetailBean;
import com.mobiowin.windchim.bean.EventMasterBean;
import com.mobiowin.windchim.bean.SliderMasterBean;
import com.mobiowin.windchim.bean.SurveyMasterBean;
import com.mobiowin.windchim.commons.ApplicationConstant;
import com.mobiowin.windchim.commons.MessageUtility;
import com.mobiowin.windchim.dao.IAppSyncHelperDao;
import com.mobiowin.windchim.test.DateUtility;

@Service("appSyncService")
@Component
public class AppSyncHelperServie implements IAppSyncHelperServie {
	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private IAppSyncHelperDao appSyncDao;

	@Autowired
	private @Resource Map<String, String> windchim;

	public boolean checkAppversion(HashMap<String, String> appReqDataMap) {
		log.info("AppSyncHelperServie/checkAppversion()");

		String appVersion = (String) windchim.get("version");

		log.info("App version is : " + appVersion);

		boolean isValidVersion = false;

		if (appVersion.endsWith(appReqDataMap.get(ApplicationConstant.APP_VERSION))) {
			isValidVersion = true;
		}

		return isValidVersion;
	}

	public String generateSuccessResponse() {
		HashMap<String, Object> appVersioResMap = null;
		appVersioResMap = new HashMap<String, Object>();
		String response = MessageUtility
				.createJSONFromMap(MessageUtility.createSuccessResponseMessage(appVersioResMap));
		return response;
	}

	public String syncApplciationData() {
		// TODO Auto-generated method stub
		return null;
	}

	public String generateErrorResponse() {
		// TODO Auto-generated method stub
		return null;
	}

	public String submitDeviceDetails(HashMap<String, String> deviceDetailMap) {
		log.info("Inside AppSyncHelperServie/submitDeviceDetails");

		DeviceDetailBean deviceDetailBean = null;
		boolean isUserExist = false;
		String response = null;
		HashMap<String, Object> dataMap = null;

		if (null != deviceDetailMap) {
			deviceDetailBean = new DeviceDetailBean();
			deviceDetailBean.setImeiNo(deviceDetailMap.get(ApplicationConstant.IMEI_NO));
			deviceDetailBean.setDeviceId(deviceDetailMap.get(ApplicationConstant.DEVICE_ID));
			deviceDetailBean.setDeviceModel(deviceDetailMap.get(ApplicationConstant.DEVICE_MODEL));
			deviceDetailBean.setOsVersion(deviceDetailMap.get(ApplicationConstant.OS_VERSION));
			deviceDetailBean.setNotificationId(deviceDetailMap.get(ApplicationConstant.NOTIFICATION_ID));
			deviceDetailBean.setCreatedBy(ApplicationConstant.SYSTEM_CREATED_BY);
			deviceDetailBean.setCreateDt(DateUtility.getTimeStamp());
			deviceDetailBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);
		}

		isUserExist = appSyncDao.isUserExist(deviceDetailBean);

		if (!isUserExist) {
			response = appSyncDao.submitUser(deviceDetailBean);

			if (response.equals(ApplicationConstant.TRUE)) {
				dataMap = new HashMap<String, Object>();

				return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));
			}
		} else {
			deviceDetailBean.setModifiedBy(ApplicationConstant.SYSTEM_MODIFIED_BY);
			deviceDetailBean.setModifyDt(DateUtility.getTimeStamp());

			response = appSyncDao.updateUser(deviceDetailBean);

			if (response.equals(ApplicationConstant.TRUE)) {
				dataMap = new HashMap<String, Object>();

				return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));
			}
		}
		return MessageUtility.createErrorMessage("Process failed due to technical issue!!! Kindly try after sometime");

	}

	public String appConfigSync(HashMap<String, String> reqDataMap) {

		log.info("Inside AppSyncHelperServie/appConfigSync()");
		HashMap<String, Object> dataMap = null;
		List<SliderMasterBean> sliderMasterList = null;
		List<BroadcastMasterBean> broadcastTopicMasterList = null;
		List<BranchMasterBean> branchMasterList = null;

		log.info("orgRegistrationDataMap : " + reqDataMap);

		sliderMasterList = appSyncDao.syncAppBanner(reqDataMap.get(ApplicationConstant.LAST_SYNC_DATE));
		branchMasterList = appSyncDao.syncBranchDetails(reqDataMap.get(ApplicationConstant.LAST_SYNC_DATE));
		broadcastTopicMasterList = appSyncDao.syncBroadcastTopic(reqDataMap.get(ApplicationConstant.LAST_SYNC_DATE));

		if (null != sliderMasterList && null != broadcastTopicMasterList && null != branchMasterList) {
			dataMap = new HashMap<String, Object>();
			dataMap.put(ApplicationConstant.BANNER_LIST, sliderMasterList);
			dataMap.put(ApplicationConstant.BROADCAST_TOPIC_LIST, broadcastTopicMasterList);
			dataMap.put(ApplicationConstant.BRANCH_DETAILS_LIST, branchMasterList);

			dataMap.put(ApplicationConstant.LAST_SYNC_DATE, DateUtility.getTimeStamp());
			return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));

		} else {
			return MessageUtility
					.createErrorMessage("Some issues while Sync App data for you, Kindly try after some time!!!");
		}

	}

	public String submitMessage(HashMap<String, String> reqDataMap) {
		log.info("Inside AppSyncHelperServie/submitMessage()");

		ConnectBean connectBean = null;
		String dbResponse = null;
		HashMap<String, Object> dataMap = null;

		if (null != reqDataMap) {
			connectBean = new ConnectBean();
			connectBean.setName(reqDataMap.get(ApplicationConstant.NAME));
			connectBean.setEmailId(reqDataMap.get(ApplicationConstant.EMAIL_ID));
			connectBean.setMobileNo(reqDataMap.get(ApplicationConstant.MOBILE_NO));
			connectBean.setMessage(reqDataMap.get(ApplicationConstant.MESSAGE));
			connectBean.setCreatedBy(ApplicationConstant.SYSTEM_CREATED_BY);
			connectBean.setCreateDt(DateUtility.getTimeStamp());
			connectBean.setModifiedBy(ApplicationConstant.SYSTEM_MODIFIED_BY);
			connectBean.setModifyDt(DateUtility.getTimeStamp());
			connectBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);

			dbResponse = appSyncDao.submitMessage(connectBean);

			if (dbResponse.equals(ApplicationConstant.TRUE)) {

				dataMap = new HashMap<String, Object>();

				return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));
			} else {
				return MessageUtility
						.createErrorMessage("Process failed due to some technical issue,Kindly try after some time!!!");
			}

		}

		return MessageUtility
				.createErrorMessage("Process failed due to some technical issue,Kindly try after some time!!!");
	}

	public String syncEvent(HashMap<String, String> reqDataMap) {
		log.info("Inside AppSyncHelperServie/syncEvent()");

		EventMasterBean eventMasterBean = null;
		HashMap<String, Object> dataMap = null;
		List<EventMasterBean> eventList = null;
		List<EventMasterBean> eventByTypeList = null;
		Timestamp currentTime = null;
		log.info("orgRegistrationDataMap : " + reqDataMap);

		if (null != reqDataMap && null != reqDataMap.get(ApplicationConstant.EVENT_ID)
				&& !reqDataMap.get(ApplicationConstant.EVENT_ID).equals(ApplicationConstant.EMPTY_STRING)) {
			eventMasterBean = new EventMasterBean();
			eventMasterBean.setEventId(reqDataMap.get(ApplicationConstant.EVENT_ID));
			eventMasterBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);

			eventList = appSyncDao.syncEventById(eventMasterBean);

			if (null != eventList) 
			{
				eventByTypeList = new ArrayList<EventMasterBean>();
				for (EventMasterBean eventBean : eventList) {

					currentTime = new Timestamp(new Date().getTime());

					log.info("timestamp1 is : " + currentTime);

					if (currentTime.after(eventBean.getEndDt())) 
					{
						log.info("Previous event");
						eventBean.setEventType(ApplicationConstant.PREVIOUS_EVENT);
						eventByTypeList.add(eventBean);
					}
					else
					{
						eventBean.setEventType(ApplicationConstant.UPCOMING_EVENT);
						eventByTypeList.add(eventBean);
					}
				}
				dataMap = new HashMap<String, Object>();
				dataMap.put(ApplicationConstant.EVENT_LIST, eventByTypeList);
				return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));

			}
		} else if (null != reqDataMap) {
			eventMasterBean = new EventMasterBean();
			eventMasterBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);

			eventList = appSyncDao.syncEvent(eventMasterBean, reqDataMap.get(ApplicationConstant.LAST_SYNC_DATE));
			
			if (null != eventList) {
				eventByTypeList = new ArrayList<EventMasterBean>();
				for (EventMasterBean eventBean : eventList) {

					currentTime = new Timestamp(new Date().getTime());

					log.info("timestamp1 is : " + currentTime);

					if (currentTime.after(eventBean.getEndDt())) 
					{
						log.info("Previous event");
						eventBean.setEventType(ApplicationConstant.PREVIOUS_EVENT);
						eventByTypeList.add(eventBean);
					}
					else
					{
						eventBean.setEventType(ApplicationConstant.UPCOMING_EVENT);
						eventByTypeList.add(eventBean);
					}
				}
				dataMap = new HashMap<String, Object>();
				dataMap.put(ApplicationConstant.EVENT_LIST, eventByTypeList);
				dataMap.put(ApplicationConstant.LAST_SYNC_DATE, DateUtility.getTimeStamp());
				return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));

			}
		}

		else {
			return MessageUtility
					.createErrorMessage("Some issues while fetching event data for you, Kindly try after some time!!!");
		}

		return MessageUtility
				.createErrorMessage("Some issues while fetching event data for you, Kindly try after some time!!!");
	}

	public String submitLeadMessage(HashMap<String, String> reqDataMap) {

		log.info("Inside AppSyncHelperServie/submitLeadMessage()");

		SurveyMasterBean surveyMasterBean  = null;
		String dbResponse = null;
		HashMap<String, Object> dataMap = null;

		if (null != reqDataMap) {
			surveyMasterBean = new SurveyMasterBean();
			surveyMasterBean.setName(reqDataMap.get(ApplicationConstant.NAME));
			surveyMasterBean.setEmailId(reqDataMap.get(ApplicationConstant.EMAIL_ID));
			surveyMasterBean.setMobileNo(reqDataMap.get(ApplicationConstant.MOBILE_NO));
			surveyMasterBean.setMessage(reqDataMap.get(ApplicationConstant.MESSAGE));
			surveyMasterBean.setChildName(reqDataMap.get(ApplicationConstant.LEAD_NAME));
			surveyMasterBean.setAddress(reqDataMap.get(ApplicationConstant.ADDRESS));
			surveyMasterBean.setCreatedBy(ApplicationConstant.SYSTEM_CREATED_BY);
			surveyMasterBean.setCreateDt(DateUtility.getTimeStamp());
			surveyMasterBean.setModifiedBy(ApplicationConstant.SYSTEM_MODIFIED_BY);
			surveyMasterBean.setModifyDt(DateUtility.getTimeStamp());
			surveyMasterBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);

			dbResponse = appSyncDao.submitSurveyMessage(surveyMasterBean);

			if (dbResponse.equals(ApplicationConstant.TRUE)) {

				dataMap = new HashMap<String, Object>();

				return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));
			} else {
				return MessageUtility
						.createErrorMessage("Process failed due to some technical issue,Kindly try after some time!!!");
			}

		}

		return MessageUtility
				.createErrorMessage("Process failed due to some technical issue,Kindly try after some time!!!");
	
	}

}
