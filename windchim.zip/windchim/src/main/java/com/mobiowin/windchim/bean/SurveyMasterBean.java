package com.mobiowin.windchim.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "survey_master", catalog = "windchimp")
public class SurveyMasterBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private String id;
	
	@Column(name = "name")
	private String name;
	
	@Column(name = "email_id")
	private String emailId;
	
	@Column(name = "mobile_no")
	private String mobileNo;
	
	@Column(name = "message")
	private String message;
	
	@Column(name = "child_name")
	private String childName;
	
	@Column(name = "address")
	private String address;
	
	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_dt")
	private Date createDt;

	@Column(name = "modified_by")
	private String modifiedBy;

	@Column(name = "modified_dt")
	private Date modifyDt;

	@Column(name = "del_flag")
	private String deleteFlag;

	public SurveyMasterBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SurveyMasterBean(String id, String name, String emailId, String mobileNo, String message, String childName,
			String address, String createdBy, Date createDt, String modifiedBy, Date modifyDt, String deleteFlag) {
		super();
		this.id = id;
		this.name = name;
		this.emailId = emailId;
		this.mobileNo = mobileNo;
		this.message = message;
		this.childName = childName;
		this.address = address;
		this.createdBy = createdBy;
		this.createDt = createDt;
		this.modifiedBy = modifiedBy;
		this.modifyDt = modifyDt;
		this.deleteFlag = deleteFlag;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getChildName() {
		return childName;
	}

	public void setChildName(String childName) {
		this.childName = childName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifyDt() {
		return modifyDt;
	}

	public void setModifyDt(Date modifyDt) {
		this.modifyDt = modifyDt;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	@Override
	public String toString() {
		return "SurveyMasterBean [id=" + id + ", name=" + name + ", emailId=" + emailId + ", mobileNo=" + mobileNo
				+ ", message=" + message + ", childName=" + childName + ", address=" + address + ", createdBy="
				+ createdBy + ", createDt=" + createDt + ", modifiedBy=" + modifiedBy + ", modifyDt=" + modifyDt
				+ ", deleteFlag=" + deleteFlag + "]";
	}
	
	

}
