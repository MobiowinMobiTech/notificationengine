package com.mobiowin.windchim.test;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateTest {

	public static void main(String[] args) {
		/*String x = "1086073200000";

				DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");

				long milliSeconds= Long.parseLong(x);
				System.out.println(milliSeconds);

				Calendar calendar = Calendar.getInstance();
				calendar.setTimeInMillis(milliSeconds);
				System.out.println(formatter.format(calendar.getTime())); */
		
		
		try
		{
			Timestamp.valueOf(DateUtility.syncDateparser("1488545944000"));
		}catch(Exception e){//this generic but you can control another types of exception
		
		}
		
		try {
			Timestamp ts = Timestamp.valueOf(DateUtility.syncDateparser("1488545944000"));
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
			Date fechaNueva = format.parse(ts.toString());
			format = new SimpleDateFormat("dd MMM YYY");
			System.out.println(format.format(fechaNueva));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
	}
}
