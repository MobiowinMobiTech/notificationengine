package com.cmss.notification.messaging;

import org.springframework.messaging.Message;

public interface INotificationMessageReceiver {
	public Message<String> recieve(Message<String> message);
}
