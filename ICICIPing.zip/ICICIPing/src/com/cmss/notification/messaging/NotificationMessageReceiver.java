package com.cmss.notification.messaging;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service("messageReceiver")
@Component
public class NotificationMessageReceiver implements INotificationMessageReceiver {

	private Log log = LogFactory.getLog(getClass());

	public Message<String> recieve(Message<String> message) {

		log.info("Inside SimpleMessageReceiver / recieve().....");
		
		return null;

	}

}
