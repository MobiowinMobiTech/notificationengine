package com.cmss.notification.messaging;

import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

public class NotificationGateway extends HttpServlet 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Log log = LogFactory.getLog(getClass());

	/**
	 * @see HttpServlet#HttpServlet()
	 */

	public NotificationGateway() {
		super();
	}
	

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@SuppressWarnings("unchecked")
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException 
	{
		ApplicationContext applicationContext = WebApplicationContextUtils
				.getRequiredWebApplicationContext(getServletContext());

		Map<String, String> systemMap = applicationContext.getBean("NotificationInfo", Map.class);

		StringBuilder systemInfo = new StringBuilder("Notification Info is : ");

		for (String key : systemMap.keySet()) {
			systemInfo.append("\n").append(key).append(" : ")
					.append(systemMap.get(key));
		}

		systemInfo.append("\n");

		if (log.isInfoEnabled()) {
			log.info("System info is ---------- > " + systemInfo.toString());
		}

		response.getOutputStream().write(systemInfo.toString().getBytes());
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		ApplicationContext applicationContext = WebApplicationContextUtils
				.getRequiredWebApplicationContext(getServletContext());
		
		log.info("Application context is : " + applicationContext);
	}
}
