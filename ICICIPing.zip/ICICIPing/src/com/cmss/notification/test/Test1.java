package com.cmss.notification.test;

import org.apache.log4j.chainsaw.Main;

public class Test1 
{
	public Test1()
	{
		
	}
	
	public void printName()
	{
		System.out.println("In test 1");
	}
}

class Child extends Test1
{
	public void printName()
	{
		System.out.println("In Child");
	}
}

class Test2
{
	public static void main(String[] args) 
	{
		//Child c = (Child)new Test1();
		Test1 c = new Child();
		c.printName();

	}
	
	
}