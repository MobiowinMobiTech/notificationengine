package com.cmss.notification.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Test {

	
			
	public static void main(String[] args) 
	{
		List<HashMap<String,String>> testDataMapList = new ArrayList<HashMap<String,String>>();
		
		HashMap<String,String> testDataMap = new HashMap<String,String>();
		HashMap<String,String> testDataMap1 = new HashMap<String,String>();
		HashMap<String,String> testDataMap2= new HashMap<String,String>();
		HashMap<String,String> testDataMap3 = new HashMap<String,String>();
		HashMap<String,String> testDataMap4 = new HashMap<String,String>();
		HashMap<String,String> testDataMap5 = new HashMap<String,String>();
		
		testDataMap.put("TM_CL_RSP_EMP_ID","139092");
		testDataMap.put("name","139092");
		testDataMap.put("age","139092");
		
		testDataMap1.put("TM_CL_RSP_EMP_ID","139092");
		testDataMap.put("name","139092");
		testDataMap2.put("TM_CL_RSP_EMP_ID","139091");
		testDataMap3.put("TM_CL_RSP_EMP_ID","139092");
		testDataMap4.put("TM_CL_RSP_EMP_ID","139093");
		testDataMap5.put("TM_CL_RSP_EMP_ID","139093");
		
		testDataMapList.add(testDataMap);
		testDataMapList.add(testDataMap1);
		testDataMapList.add(testDataMap2);
		testDataMapList.add(testDataMap3);
		testDataMapList.add(testDataMap4);
		testDataMapList.add(testDataMap5);
		
		System.out.println("Testdatamap list is : "+ testDataMapList);
		
		//List<String> idList = (List<String>) CollectionUtils.collect(testDataMapList,new BeanToPropertyValueTransformer("id"));
		
		List<String> empIdList = new ArrayList<String>();
		
		for(HashMap<String,String> map : testDataMapList)
		{
			empIdList.add(map.get("TM_CL_RSP_EMP_ID"));
		}
		
		System.out.println("empIdList : " + empIdList);
		
		Set<String> uniqueEmpIdset = new HashSet<String>(empIdList);
		
		System.out.println("uniqueEmpIdset : " + uniqueEmpIdset);
		
		List<String> uniqueEmpIdList = new ArrayList<String>(uniqueEmpIdset);
		
		System.out.println("uniqueEmpIdList : " + uniqueEmpIdList);
	}
	
	
}
