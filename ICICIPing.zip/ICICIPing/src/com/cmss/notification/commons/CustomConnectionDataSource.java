package com.cmss.notification.commons;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.TransactionAwareDataSourceProxy;
import org.springframework.stereotype.Component;

import com.mchange.v2.c3p0.ComboPooledDataSource;

@Component
public class CustomConnectionDataSource extends TransactionAwareDataSourceProxy {

    @Autowired
    CustomConnectionDataSource(ComboPooledDataSource dataSource) {
        super.setTargetDataSource(decryptPassword(dataSource));
    }

    private DataSource decryptPassword(ComboPooledDataSource dataSource) {
        try {
            dataSource.setPassword(AESAlgoClass.decrypt(dataSource.getPassword()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dataSource;
    }    
}