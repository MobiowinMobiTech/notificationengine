package com.cmss.notification.commons;

public interface ApplicationConstant
{
	public class AuditConstants
	{
		  public static final String ADT_TYP_CD = "ADT_TYP_CD";
		  public static final String ADT_UID = "ADT_UID";
		  public static final String ADT_BWSR = "ADT_BWSR";
		  public static final String ADT_IP = "ADT_IP";
		  public static final String ADT_DT_TME = "ADT_DT_TME";
		  public static final String ADT_DATA = "ADT_DATA";
		  public static final String ADT_RSTR = "ADT_RSTR";
		  public static final String ADT_GRADE = "ADT_GRADE";
	}
	
	public class FCMConstants
	{
		public static final String FCM_SERVER_AUTH_KEY = "serverkey";
		
		public static final String FCM_NOTIFICATION_URL = "fcmurl";
	}
	
	public class CommonConstants
	{
		public static final String PROCESSED = "P";
		
		public static final String SUCCESS  = "success";
		
		public static final String FAILURE  = "failure";
		
		
	}

}
