package com.cmss.notification.commons;

import java.security.Security;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

public class AESAlgoClass {
	public static final String STR_KEY = "GKsks749JWHHsu43";
	public static final String STR_IV = "Ks8730Jwimak39IU";

	public static String encrypt(String strPlainText) throws Exception {
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		Cipher aes = Cipher.getInstance("AES/CBC/PKCS7PADDING");
		IvParameterSpec iv = new IvParameterSpec(STR_IV.getBytes("UTF-8"));

		byte[] key = STR_KEY.getBytes("UTF-8");
		SecretKeySpec secretKey = new SecretKeySpec(key, "AES");
		aes.init(Cipher.ENCRYPT_MODE, secretKey, iv);
		String strEncryptedText = Base64.encodeBase64String(aes.doFinal(strPlainText.getBytes("UTF-8")));
		return strEncryptedText;
	}

	public static String decrypt(String strEncryptedText) throws Exception {
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		Cipher aes = Cipher.getInstance("AES/CBC/PKCS7PADDING");
		IvParameterSpec iv = new IvParameterSpec(STR_IV.getBytes("UTF-8"));

		byte[] key = STR_KEY.getBytes("UTF-8");
		SecretKeySpec secretKey = new SecretKeySpec(key, "AES");
		aes.init(Cipher.DECRYPT_MODE, secretKey, iv);
		String strDecryptedText = new String(aes.doFinal(Base64.decodeBase64(strEncryptedText)), "UTF-8");
		
		return strDecryptedText;
	}
	
	public static void main(String[] args) {
		
		try
		{
			System.out.println(" " + AESAlgoClass.decrypt("K35Mm21hXIe9/9lyHOyeKg=="));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}