/*     */ package com.cmss.notification.commons;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.sql.Timestamp;
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Locale;
/*     */ 
/*     */ public class DateUtility
/*     */ {
/*     */   public static final String DAYS = "DAYS";
/*     */   public static final String HOURS = "HRS";
/*     */   public static final String MINUTES = "MIN";
/*     */   public static final String SECONDS = "SEC";
/*     */   public static final long SECOND_MILLIS = 1000L;
/*     */   public static final long MINUTE_MILLIS = 60000L;
/*     */   public static final long HOUR_MILLIS = 3600000L;
/*     */   public static final long DAY_MILLIS = 86400000L;
/*     */   public static final long YEAR_MILLIS = 31536000000L;
/*     */   public static Hashtable hashTab;
/*     */ 
/*     */   public static Timestamp getCurrentDate()
/*     */   {
/*  36 */     Date today = new Date();
/*  37 */     return new Timestamp(today.getTime());
/*     */   }
/*     */ 
/*     */   public static Timestamp addDays(Timestamp timestamp, int intDays) {
/*  41 */     Calendar c1 = GregorianCalendar.getInstance();

/*  44 */     c1.set(Integer.parseInt(timestamp.toString().substring(0, 4)), 
/*  45 */       timestamp.getMonth(), timestamp.getDate());
/*  46 */     c1.add(5, intDays);
/*  47 */     Date date = c1.getTime();
/*  48 */     return new Timestamp(date.getTime());
/*     */   }
/*     */ 
/*     */   public static Timestamp stripTime(Timestamp timestamp) {
/*  52 */     return Timestamp.valueOf(timestamp.toString().substring(0, 10) + 
/*  53 */       " 00:00:00.000");
/*     */   }
/*     */ 
/*     */   public static Timestamp appendTime(Timestamp timestamp) {
/*  57 */     return Timestamp.valueOf(timestamp.toString().substring(0, 10) + 
/*  58 */       " 23:59:59.000");
/*     */   }
/*     */ 
/*     */   public static Timestamp parseStringToDate(String strDate) {
/*  62 */     DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
/*  63 */     Date today = null;
/*     */     try {
/*  65 */       today = df.parse(strDate);
/*     */     }
/*     */     catch (ParseException e) {
/*  68 */       e.printStackTrace();
/*     */     }
/*     */     finally {
/*  71 */       return new Timestamp(today.getTime());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Timestamp parseStringToDate(String strDate, String strFormat)
/*     */   {
/*  78 */     DateFormat df = new SimpleDateFormat(strFormat);
/*  79 */     Date today = null;
/*     */     try {
/*  81 */       today = df.parse(strDate);
/*     */     }
/*     */     catch (ParseException e) {
/*  84 */       e.printStackTrace();
/*     */     } finally {
/*  86 */       return new Timestamp(today.getTime());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String parseDateToString(Date today, String strFormat)
/*     */   {
/*  92 */     DateFormat df = new SimpleDateFormat(strFormat);
/*  93 */     return df.format(today);
/*     */   }
/*     */ 
/*     */   public static String parseDateToString(Date today) {
/*  97 */     DateFormat df = new SimpleDateFormat("dd-MMM-yy");
/*  98 */     return df.format(today);
/*     */   }
/*     */ 
/*     */   public static Integer getTimeInInteger() {
/* 102 */     Date today = new Date();
/* 103 */     DateFormat df = new SimpleDateFormat("kkmmssSSS");
/* 104 */     return Integer.valueOf(Integer.parseInt(df.format(today)));
/*     */   }
/*     */ 
/*     */   public static String formatDate(Timestamp tDate, int iDateFormat, Locale userLocale)
/*     */   {
/* 109 */     DateFormat df = null;
/*     */ 
/* 111 */     if (tDate == null) {
/* 112 */       return "";
/*     */     }
/*     */ 
/* 115 */     if (iDateFormat < 3)
/* 116 */       df = DateFormat.getDateInstance(3, userLocale);
/*     */     else {
/* 118 */       df = DateFormat.getDateInstance(2, userLocale);
/*     */     }
/*     */     try
/*     */     {
/* 122 */       String formattedDate = df.format(tDate);
/* 123 */       return formattedDate; } catch (IllegalArgumentException e) {
/*     */     }
/* 125 */     return "";
/*     */   }
/*     */ 
/*     */   public static long getDaysDifference(Timestamp time1, Timestamp time2, String strType)
/*     */   {
/* 133 */     long timeDifference = time1.getTime() - time2.getTime();
/*     */ 
/* 136 */     if (strType.equals("DAYS")) {
/* 137 */       time1 = stripTime(time1);
/* 138 */       time2 = stripTime(time2);
/* 139 */       timeDifference = time1.getTime() - time2.getTime();
/* 140 */       timeDifference /= 86400000L;
/* 141 */     } else if (strType.equals("HRS")) {
/* 142 */       timeDifference /= 3600000L;
/* 143 */     } else if (strType.equals("MIN")) {
/* 144 */       timeDifference /= 60000L;
/* 145 */     } else if (strType.equals("SEC")) {
/* 146 */       timeDifference /= 1000L;
/*     */     } else {
/* 148 */       timeDifference = 0L;
/*     */     }
/* 150 */     return timeDifference;
/*     */   }
/*     */ 
/*     */   public static int hoursDiff(Date earlierDate, Date laterDate)
/*     */   {
/* 377 */     if ((earlierDate == null) || (laterDate == null)) {
/* 378 */       return 0;
/*     */     }
/* 380 */     return (int)(laterDate.getTime() / 3600000L - earlierDate
/* 381 */       .getTime() / 3600000L);
/*     */   }
/*     */ }

/* Location:           D:\projects\eNgage\EngageProjects\EngageIntegrationDecompile\WEB-INF\classes\
 * Qualified Name:     com.cmss.engage.util.DateUtility
 * JD-Core Version:    0.6.0
 */