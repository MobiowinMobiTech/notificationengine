package com.cmss.notification.commons;

import java.util.concurrent.TimeUnit;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.conn.HttpClientConnectionManager;
import org.springframework.stereotype.Component;

@Component
public class IdleConnectionMonitorThread extends Thread 
{
	private Log log = LogFactory.getLog(this.getClass());

	private final HttpClientConnectionManager connMgr;
	private volatile boolean shutdown;
	private long idleTimeoutInMS;

	public IdleConnectionMonitorThread(HttpClientConnectionManager connMgr, long idleTimeoutInMS) {
		super();
		this.connMgr = connMgr;
		this.idleTimeoutInMS = idleTimeoutInMS;
	}

	@Override
	public void run() {

		try {
			while (!shutdown) {
				synchronized (this) {
					wait(5000);
					// Close expired connections
					connMgr.closeExpiredConnections();
					// Optionally, close connections
					connMgr.closeIdleConnections(idleTimeoutInMS, TimeUnit.MILLISECONDS);
				}
			}
		} catch (InterruptedException ex) {
			log.error(ex.getMessage(), ex);
		}
	}

	public void shutdown() {
		shutdown = true;
		synchronized (this) {
			notifyAll();
		}
	}

}