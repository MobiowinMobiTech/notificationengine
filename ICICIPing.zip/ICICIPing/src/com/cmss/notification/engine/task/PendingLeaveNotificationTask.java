package com.cmss.notification.engine.task;

import java.util.TimerTask;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cmss.notification.engine.service.INotificationDataFetchService;

@EnableAsync
@Service("pendingNotificationTask")
@Component
public class PendingLeaveNotificationTask extends TimerTask {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private INotificationDataFetchService notificationDataFetchService;

	private boolean pendingLeaveNotificationTask;

	public boolean isPendingLeaveNotificationTask() {
		return pendingLeaveNotificationTask;
	}

	public void setPendingLeaveNotificationTask(boolean pendingLeaveNotificationTask) {
		this.pendingLeaveNotificationTask = pendingLeaveNotificationTask;
	}

	@Override
	public void run() {
		log.info("Inside PendingLatePunchNotificationTask/run()");

		if (isPendingLeaveNotificationTask()) {
			try {
				log.info("=========Leave Notification Data Fetch From PS Task Is Set To ON=======");

				notificationDataFetchService.fetchPsLeaveNotificationData();

				Thread.sleep(5000);
			} catch (Exception e) {
				log.error("Error While Fetching Leave Notification data from Peoplesoft : " + e.getMessage(),
						e.getCause());
				e.printStackTrace();
			}
		}

	}

}
