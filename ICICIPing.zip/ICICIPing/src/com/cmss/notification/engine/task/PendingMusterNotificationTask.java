package com.cmss.notification.engine.task;

import java.util.TimerTask;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.cmss.notification.engine.service.INotificationDataFetchService;

public class PendingMusterNotificationTask extends TimerTask {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private INotificationDataFetchService notificationDataFetchService;

	@Override
	public void run() {
		log.info("Inside PendingLatePunchNotificationTask/run()");

		//notificationDataFetchService.fetchMusterNotificationData();

	}

}
