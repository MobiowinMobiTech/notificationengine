package com.cmss.notification.engine.dao;

import java.util.List;

import com.cmss.notification.bean.NotificationDataTemp;

public interface IUotmNotificationDao {

	String submitLeaveNotificationData(List<NotificationDataTemp> notificationDataList);

}
