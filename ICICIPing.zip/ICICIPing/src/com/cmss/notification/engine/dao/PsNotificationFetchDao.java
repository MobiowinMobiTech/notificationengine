package com.cmss.notification.engine.dao;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.cmss.notification.commons.ApplicationConstant;

@Repository("psNotificationDao")
@Component
public class PsNotificationFetchDao implements IPsNotificationFetchDao{

	private Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private SessionFactory sessionFactory;
	
	Session session = null;
	Transaction transaction = null;
	
	@Override
	public List<Object[]> fetchLeaveNotificationData() 
	{
		log.info("Inside PsNotificationFetchDao/fetchMusterNotificationData()");
		
		StringBuilder fetchMusterNotificationDataQueryBuilder  = new StringBuilder();
		fetchMusterNotificationDataQueryBuilder.append("SELECT TO_CHAR(ROWIDTONCHAR(ROWID)) AS UNI, KEY1_FLDNAME, EMPLID_FROM, EMPLID_TO,");
		fetchMusterNotificationDataQueryBuilder.append("NAME_ADMIN, NAME_AC,TO_CHAR(COMMENTS_2000) AS COMMENTS,");
		fetchMusterNotificationDataQueryBuilder.append("CREATEDTTM,EOEN_NOTIFY_TO,EMAIL_ADDR,PHONE FROM  SYSADM.PS_ICI_MOB_NOT_RUN ");
		fetchMusterNotificationDataQueryBuilder.append("WHERE ROWNUM<= 100 ORDER BY CREATEDTTM ASC");
		
		log.info("Fetch Muster Notification Data Query is : " + fetchMusterNotificationDataQueryBuilder.toString());
		
		Query query  = sessionFactory.openSession().createQuery(fetchMusterNotificationDataQueryBuilder.toString());
		
		List<Object[]> pendingMusterNotificationList = query.list();
		
		log.info("Pending muster notification list is : " + pendingMusterNotificationList);
		
		return pendingMusterNotificationList;
		
	}

	@Override
	public String deletePsLeaveNotificationData(List<String> psRowIdList) 
	{
		log.info("PsNotificationFetchDao/deletePsLeaveNotificationData()");
		
		StringBuilder deleteLeaveNotificationDataQueryBuilder  = new StringBuilder();
		deleteLeaveNotificationDataQueryBuilder.append("DELETE FROM SYSADM.PS_ICI_MOB_NOT_RUN");
		deleteLeaveNotificationDataQueryBuilder.append("WHERE ROWID IN (" + psRowIdList + ")");
		
		log.info("deleteLeaveNotificationDataQuery is : " + deleteLeaveNotificationDataQueryBuilder.toString());
		
		try
		{
			Query query  = sessionFactory.openSession().createQuery(deleteLeaveNotificationDataQueryBuilder.toString());
			
			int psLeaveNotificationDeleteStatus = query.executeUpdate();
			
			log.info("Ps Leave Notification Delete Status is : " + psLeaveNotificationDeleteStatus);
			
			session.clear();
			session.flush();
			transaction.commit();
			
			return  ApplicationConstant.CommonConstants.SUCCESS;
		} 
		catch (HibernateException e) 
		{
			transaction.rollback();
			session.flush();
			log.error("Exception in deleteing leave records from PS : " + e.getMessage(),e.getCause());
			e.printStackTrace();
			return ApplicationConstant.CommonConstants.FAILURE;
		}
	}

	@Override
	public List<Object[]> fetchMusterNotificationData() {
		// TODO Auto-generated method stub
		return null;
	}

}
