package com.cmss.notification.engine.dao;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.cmss.notification.bean.NotificationDataTemp;
import com.cmss.notification.commons.ApplicationConstant;

@Repository("uotmNotificationDao")
@Component
public class UotmNotificationDao implements IUotmNotificationDao{
	
	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private SessionFactory sessionFactory;

	Session session = null;
	Transaction transaction = null;
	
	@Override
	public String submitLeaveNotificationData(List<NotificationDataTemp> notificationDataList) 
	{
		log.info("Inside UotmNotificationDao/submitLeaveNotificationData()");
		
		try 
		{
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			for(NotificationDataTemp notificationDataTemp : notificationDataList)
			{
				session.save(notificationDataTemp);
				session.flush();
				session.clear();
				transaction.commit();
			}

			return ApplicationConstant.CommonConstants.SUCCESS;
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
			log.error("Exception in registerMerchant : " + e.getMessage(), e.getCause());
			return ApplicationConstant.CommonConstants.FAILURE;
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			log.error("Exception in registerMerchant : " + ex.getMessage(), ex.getCause());
			return ApplicationConstant.CommonConstants.FAILURE;
		}
	}

}
