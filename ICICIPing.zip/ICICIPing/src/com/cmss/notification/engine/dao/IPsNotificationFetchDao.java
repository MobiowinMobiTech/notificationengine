package com.cmss.notification.engine.dao;

import java.util.List;

public interface IPsNotificationFetchDao {

	List<Object[]> fetchMusterNotificationData();

	String deletePsLeaveNotificationData(List<String> psRowIdList);

	List<Object[]> fetchLeaveNotificationData();

}
