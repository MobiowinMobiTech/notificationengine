package com.cmss.notification.engine.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cmss.notification.bean.NotificationDataTemp;
import com.cmss.notification.commons.ApplicationConstant;
import com.cmss.notification.commons.DateUtility;
import com.cmss.notification.engine.dao.IPsNotificationFetchDao;
import com.cmss.notification.engine.dao.IUotmNotificationDao;
import com.cmss.notification.fcm.integration.IFCMIntegrationService;

@Service("notificationDataFetchService")
@Component
public class NotificationDataFetchService implements INotificationDataFetchService {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private IFCMIntegrationService fcmIntegrationService;

	@Autowired
	private IPsNotificationFetchDao psNotificationDao;
	
	@Autowired
	private IUotmNotificationDao uotmNotificationDao;

	@Override
	public void fetchPsMusterNotificationData() {
		log.info("Inside NotificationDataFetchService/fetchPsMusterNotificationData()");

	}

	@Override
	public void fetchPsLeaveNotificationData() {
		log.info("Inside NotificationDataFetchService/fetchPsLeaveNotificationData()");

		String date = DateUtility.getTimeInInteger().toString();
		List<NotificationDataTemp> notificationDataList = null;
		List<String> psRowIdList = null;
		List<Object[]> leaveNotificationDataList = null;
		String isDeleted = null;
		String isSubmit = null;
		log.info("Logger Date is : " + date);

		try
		{
			leaveNotificationDataList = psNotificationDao.fetchLeaveNotificationData();

			if (null != leaveNotificationDataList) 
			{
				log.info("LeaveNotificationDataList size is : " + leaveNotificationDataList.size());
				
				notificationDataList = new ArrayList<NotificationDataTemp>();
				psRowIdList = new ArrayList<String>();
				
				for(Object[] musterNotificationData : leaveNotificationDataList)
				{
					NotificationDataTemp notificationDataTemp = null;
					try 
					{
						notificationDataTemp = new NotificationDataTemp();
						
						notificationDataTemp.setKeyIdentifier(String.valueOf(musterNotificationData[1]));
						notificationDataTemp.setToId(String.valueOf(musterNotificationData[2]));
						notificationDataTemp.setFromId(String.valueOf(musterNotificationData[3]));
						notificationDataTemp.setToName(String.valueOf(musterNotificationData[4]));
						notificationDataTemp.setFromName(String.valueOf(musterNotificationData[5]));
						notificationDataTemp.setNotificationParams(String.valueOf(musterNotificationData[6]));
						notificationDataTemp.setCreationTime(String.valueOf(musterNotificationData[7]));
						notificationDataTemp.setNotificationCode(String.valueOf(musterNotificationData[8]));
						notificationDataTemp.setEmailId(String.valueOf(musterNotificationData[9]));
						notificationDataTemp.setMobileNo(String.valueOf(musterNotificationData[10]));
						notificationDataTemp.setStatus(ApplicationConstant.CommonConstants.PROCESSED);
						
						notificationDataList.add(notificationDataTemp);
						psRowIdList.add(String.valueOf(musterNotificationData[0]));
					}
					catch (Exception e) 
					{
						log.error("Exception in setting data in notificationDataTemp : " + e.getMessage(),e.getCause());
						e.printStackTrace();
					}
				}
				
				log.info("Notification Data List is : " + notificationDataList.size());
				log.info("People soft rowid List is : " + psRowIdList.size());
				
				isSubmit = uotmNotificationDao.submitLeaveNotificationData(notificationDataList);
				
				if(isSubmit.equals(ApplicationConstant.CommonConstants.SUCCESS))
				{
					log.info("Leave Data submitted successfully : ");
					
					isDeleted  = psNotificationDao.deletePsLeaveNotificationData(psRowIdList);
				}
			}

		}
		catch (Exception e) 
		{
			log.error("Exception in NotificationDataFetchService/fetchPsMusterNotificationData() : " + e.getMessage(),
					e.getCause());
		}

	}

	@Override
	public void fetchPsLatePunchNotificationData() {
		log.info("Inside NotificationDataFetchService/fetchPsLatePunchNotificationData()");

	}

}
