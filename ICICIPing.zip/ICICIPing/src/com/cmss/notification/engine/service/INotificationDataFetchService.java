package com.cmss.notification.engine.service;

public interface INotificationDataFetchService {

	/*void fetchLatePunchNotificationData();

	void fetchLeaveNotificationData();

	void fetchMusterNotificationData();*/

	void fetchPsMusterNotificationData();

	void fetchPsLeaveNotificationData();

	void fetchPsLatePunchNotificationData();

}
