package com.cmss.notification.fcm.integration;

public interface IFCMIntegrationService {

	void sendFcmNotificationMessage();

}
