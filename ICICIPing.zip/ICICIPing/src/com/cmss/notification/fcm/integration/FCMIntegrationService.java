package com.cmss.notification.fcm.integration;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cmss.notification.commons.ApplicationConstant;

@Service("fcmIntegrationService")
@Component
public class FCMIntegrationService implements IFCMIntegrationService 
{
	private Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private @Resource
	Map<String, String> notificationUATConfig;
	
	//public static final String AUTH_KEY = "AAAAbkdbV8A:APA91bET2vx61ECwwWoE78F0zXV9xS3WVmB8d7KIvJCiAOebkfffGK4TwFIYpEkIP1q_Y8HVpxolgoeUBu5jC9I1z2UMCLxj4wnCC8lly_LT7F4Gjeqc-dTMm4s3tT3Ug7uvRE9OcB9dRWeHYJzBf8Nxw1NCjo0qTg";   // You FCM AUTH key
	//String FMCurl = "https://fcm.googleapis.com/fcm/send";
	
	//String fcmServerAuthKey = null;
	//String fcmNotificationUrl = null;
	HttpEntity<String> entity  = null;
	String notificationJsonData = null;
	String response = null;
	
	

	public void sendFcmNotificationMessage() 
	{
		
		HashMap<String,String> fcmServerDetails = fetchFcmServerDetailsMap();
		
		
		if(log.isInfoEnabled())
		{
			log.info("Fcm Server Auth Key is : " + fcmServerDetails.get(ApplicationConstant.FCMConstants.FCM_SERVER_AUTH_KEY));
			log.info("Fcm notification url is : " + fcmServerDetails.get(ApplicationConstant.FCMConstants.FCM_NOTIFICATION_URL));
		}
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Authorization","key="+fcmServerDetails.get(ApplicationConstant.FCMConstants.FCM_SERVER_AUTH_KEY));
		
		notificationJsonData = getNotificationMessageData();
		
		entity = new HttpEntity<String>(notificationJsonData,headers);
		
		// send request and parse result
		response = restTemplate.postForObject(fcmServerDetails.get(ApplicationConstant.FCMConstants.FCM_NOTIFICATION_URL), entity, String.class);
		JSONObject responseJson = new JSONObject(response);
		
		log.info("answer : " + responseJson);
		
	}

	private HashMap<String, String> fetchFcmServerDetailsMap()
	{
		HashMap<String,String> fcmServerDetailsMap = new HashMap<String,String>();
		
		fcmServerDetailsMap.put(ApplicationConstant.FCMConstants.FCM_SERVER_AUTH_KEY, String.valueOf(notificationUATConfig.get(ApplicationConstant.FCMConstants.FCM_SERVER_AUTH_KEY)));
		fcmServerDetailsMap.put(ApplicationConstant.FCMConstants.FCM_NOTIFICATION_URL, String.valueOf(notificationUATConfig.get(ApplicationConstant.FCMConstants.FCM_NOTIFICATION_URL))); 
	
		return fcmServerDetailsMap;
	}

	private String getNotificationMessageData()
	{
		log.info("inside  getNotificationMessageData()");
		String userID = "cDN_0m5JHq0:APA91bGbuH6JXPrwGXevSFhT15WpRwNkoUT0IDA9yLVWfCtwDQnzXfRyqrVAAyAxTZdExThfGN7pAGI3a7pF9CZ8VM0uc2e_1ze00oSyy3kFCu8B1f55MNu3s9tx7uBXQBTe8LHJdumW";
		JSONObject json = new JSONObject();
		json.put("to",userID.trim());
		JSONObject info = new JSONObject();
		info.put("title", "UOTM Test");   // Notification title
		info.put("body", "Testing 123"); // Notification body
		json.put("notification", info);
		
		return json.toString();
	}
	
	

}
