package com.cmss.notification.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MSTR_NTFN_LOGGER_TBL", schema = "dbo", catalog = "e_Ngage")
public class NotificationDataTemp implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue
    @Column(name = "AUDIT_ID", unique = true, nullable = false)
	private long auditId;
	
	@Column(name = "KEY_IDENTIFIER", length = 200)
    private String keyIdentifier;
	
	@Column(name = "TO_ID", length = 100)
    private String toId;
	
	@Column(name = "FROM_ID", length = 100)
    private String fromId;
	
	@Column(name = "TO_NAME", length = 100)
    private String toName;
	
	@Column(name = "FROM_NAME", length = 100)
    private String fromName;
	
	@Column(name = "NOTIFICATION_PARAMS", length = 2000)
    private String notificationParams;
	
	@Column(name = "CREATION_TIME", length = 50)
    private String creationTime;
	
	@Column(name = "NOTIFICATION_CODE", length = 50)
    private String notificationCode;
	 
	@Column(name = "EMAIL_ID", length = 150)
    private String emailId;
	
	@Column(name = "MOBILE_NO", length = 50)
    private String mobileNo;
	
	@Column(name = "STATUS", length = 2)
    private String status;
	 
	@Column(name = "MOD_TIME", length = 50)
    private String modTime;

	public NotificationDataTemp() {
		super();
	}

	public NotificationDataTemp(long auditId, String keyIdentifier, String toId, String fromId, String toName,
			String fromName, String notificationParams, String creationTime, String notificationCode, String emailId,
			String mobileNo, String status, String modTime) {
		super();
		this.auditId = auditId;
		this.keyIdentifier = keyIdentifier;
		this.toId = toId;
		this.fromId = fromId;
		this.toName = toName;
		this.fromName = fromName;
		this.notificationParams = notificationParams;
		this.creationTime = creationTime;
		this.notificationCode = notificationCode;
		this.emailId = emailId;
		this.mobileNo = mobileNo;
		this.status = status;
		this.modTime = modTime;
	}

	public long getAuditId() {
		return auditId;
	}

	public void setAuditId(long auditId) {
		this.auditId = auditId;
	}

	public String getKeyIdentifier() {
		return keyIdentifier;
	}

	public void setKeyIdentifier(String keyIdentifier) {
		this.keyIdentifier = keyIdentifier;
	}

	public String getToId() {
		return toId;
	}

	public void setToId(String toId) {
		this.toId = toId;
	}

	public String getFromId() {
		return fromId;
	}

	public void setFromId(String fromId) {
		this.fromId = fromId;
	}

	public String getToName() {
		return toName;
	}

	public void setToName(String toName) {
		this.toName = toName;
	}

	public String getFromName() {
		return fromName;
	}

	public void setFromName(String fromName) {
		this.fromName = fromName;
	}

	public String getNotificationParams() {
		return notificationParams;
	}

	public void setNotificationParams(String notificationParams) {
		this.notificationParams = notificationParams;
	}

	public String getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(String creationTime) {
		this.creationTime = creationTime;
	}

	public String getNotificationCode() {
		return notificationCode;
	}

	public void setNotificationCode(String notificationCode) {
		this.notificationCode = notificationCode;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getModTime() {
		return modTime;
	}

	public void setModTime(String modTime) {
		this.modTime = modTime;
	}

	@Override
	public String toString() {
		return "NotificationDataTemp [auditId=" + auditId + ", keyIdentifier=" + keyIdentifier + ", toId=" + toId
				+ ", fromId=" + fromId + ", toName=" + toName + ", fromName=" + fromName + ", notificationParams="
				+ notificationParams + ", creationTime=" + creationTime + ", notificationCode=" + notificationCode
				+ ", emailId=" + emailId + ", mobileNo=" + mobileNo + ", status=" + status + ", modTime=" + modTime
				+ "]";
	}
    
    

}
