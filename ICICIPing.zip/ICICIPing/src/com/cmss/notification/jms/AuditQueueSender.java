package com.cmss.notification.jms;

import java.io.IOException;
import java.util.HashMap;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import com.cmss.notification.commons.ApplicationConstant;

public class AuditQueueSender
{
	private Log log = LogFactory.getLog(this.getClass());
	
	private JmsTemplate jmsTemplate;
	private Destination defaultDestination;

	public Destination getDefaultDestination() {
		return this.defaultDestination;
	}

	public void setDefaultDestination(Destination defaultDestination) {
		this.defaultDestination = defaultDestination;
	}

	public JmsTemplate getJmsTemplate() {
		return this.jmsTemplate;
	}

	public void setJmsTemplate(JmsTemplate jmsTemplate) {
		this.jmsTemplate = jmsTemplate;
	}

	public boolean auditData(HashMap<String, Object> auditDatamap) 
	{
		log.info("Inside AuditQueueSender/auditData()");
		
		HashMap<String, String> auditQueueMap = null;
		boolean response = false;
		
		if (auditDatamap != null) 
		{
			auditQueueMap = new HashMap<String, String>();
			auditQueueMap.put("adtTypeCd", (String) auditDatamap.get(ApplicationConstant.AuditConstants.ADT_TYP_CD));
			auditQueueMap.put("adtUserId", (String) auditDatamap.get(ApplicationConstant.AuditConstants.ADT_UID));
			auditQueueMap.put("adtCreTime", (String) auditDatamap.get(ApplicationConstant.AuditConstants.ADT_DT_TME));

			auditQueueMap.put("adtParams", (String) auditDatamap.get(ApplicationConstant.AuditConstants.ADT_DATA));
			auditQueueMap.put("adtBrowser", (String) auditDatamap.get(ApplicationConstant.AuditConstants.ADT_BWSR));
			auditQueueMap.put("adtRqstr", (String) auditDatamap.get(ApplicationConstant.AuditConstants.ADT_RSTR));

			auditQueueMap.put("adtIpAddr", (String) auditDatamap.get(ApplicationConstant.AuditConstants.ADT_IP));

			ObjectMapper mapper = new ObjectMapper();
			try 
			{
				response = sendMessage(mapper.writeValueAsString(auditQueueMap));
			} catch (JsonGenerationException e) {
				e.printStackTrace();
			} catch (JsonMappingException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return response;
	}

	private boolean sendMessage(String message) {
		final String mes = message;
		try {
			this.jmsTemplate.send(new MessageCreator() {
				public TextMessage message = null;

				public Message createMessage(Session session) {
					try {
						this.message = session.createTextMessage(mes);
					} catch (JMSException e) {
						System.out.println("JMS Exception - sendMessage:" + e.getMessage());
						e.printStackTrace();
					}

					return this.message;
				}
			});
		} catch (Exception ex) {
			System.out.println("Exception while sending audit message to jms:" + ex.getMessage());
			ex.printStackTrace();
			return false;
		}

		return true;
	}
}