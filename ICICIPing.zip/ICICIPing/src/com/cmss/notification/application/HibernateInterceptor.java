package com.cmss.notification.application;

import org.hibernate.EmptyInterceptor;

public class HibernateInterceptor extends EmptyInterceptor {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String dbName;
    
    public void setDbName(String dbName){
        this.dbName=dbName;
    }
    
    @Override
    public String onPrepareStatement(String sql) {

          String prepedStatement = super.onPrepareStatement(sql);
          if(dbName!=null && !dbName.trim().equals("")){
              prepedStatement = prepedStatement.replaceAll("e_Ngage", dbName);
          }
          return prepedStatement;
    }

}